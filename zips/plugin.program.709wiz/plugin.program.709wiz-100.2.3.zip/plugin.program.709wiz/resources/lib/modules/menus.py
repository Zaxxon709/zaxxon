import os
import sys
import json
import xbmc
import xbmcgui
import xbmcplugin
import urllib
import urllib.request
from .utils import add_dir
from .colors import colors
from .db import lastchk
from uservar import buildfile, videos_url, changelog_dir
from .parser import XmlParser, TextParser, get_page
from .addonvar import (addon_name, setting, addon_icon, addon_fanart, addon_ver, local_string, translatePath, authorize,
                       kodi_ver, kodi_versions, code_name, chk_splash, chk_skin_override, quick_stats, headers, home, os_info,
                       cur_skin, uptime, total_uptime, build_ver, build_date, os_name, sys_arch, vid_list, prg_list, repo_list,
                       inst_date, UPDATE_VERSION, CURRENT_BUILD, BUILD_VERSION, BUILD_NAME, NUM_BUILDS
                       )

HANDLE = int(sys.argv[1])

COLOR1 = colors.color_text1
COLOR2 = colors.color_text2
COLOR3 = colors.color_text3
COLOR4 = colors.color_text4

# Builds cache
cache_file = translatePath("special://profile/addon_data/plugin.program.709wiz/builds_cache.json")


def load_builds_cache(): # Load the full cached builds list
    if setting("autozipsize") != "true":
        return []

    if os.path.exists(cache_file):
        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
        except Exception as e:
            xbmc.log(f"[709Wiz] Failed to read builds cache: {e}", xbmc.LOGINFO)

    return []


def parse_builds_response(response): #Parse builds from json/xml/txt response
    builds = []

    if '"name":' in response or "'name':" in response:
        builds = json.loads(response)['builds']

    elif '<name>' in response:
        xml = XmlParser(response)
        builds = xml.parse_builds()

    elif 'name=' in response:
        text = TextParser(response)
        builds = text.parse_builds()

    return builds


def main_menu():
    xbmcplugin.setPluginCategory(HANDLE, COLOR1('Main Menu'))
    
    add_dir(COLOR1(f"<><> [B]Welcome to 7o9's Wizard[/B] <><>"), '', '', addon_icon, addon_fanart, COLOR2(f'7o9Wizard v{addon_ver}\n\nSystem Uptime:  {uptime}\nTotal System Uptime:  {total_uptime}'), isFolder=False)
    
    if UPDATE_VERSION > BUILD_VERSION:
        add_dir(COLOR3(f'[B]Update Available![/B]   [{BUILD_NAME} v{UPDATE_VERSION}]'), '', 41, addon_icon, addon_fanart, COLOR2(local_string(30110)), isFolder=False)
        
    elif CURRENT_BUILD not in ['No Build Installed', 'No Build']:
        add_dir(COLOR4(f'Installed Build: {CURRENT_BUILD} v{BUILD_VERSION}'), '', '', addon_icon, addon_fanart, COLOR2(f'Install Date:  {inst_date}\nBuild Skin:  {cur_skin}\n\nVideo Add-ons  [{vid_list}]\nProgram Add-ons  [{prg_list}]\nRepositories  [{repo_list}]'), isFolder=False)

    add_dir(COLOR4(f'Kodi {code_name} v{kodi_ver}'), '', '', addon_icon, addon_fanart, COLOR2(f'Release Date: {build_date}\n\nFull Version:\n{build_ver}'), isFolder=False)

    add_dir(COLOR4(f'{os_name} OS {sys_arch}'), '', '', addon_icon, addon_fanart, COLOR2(f'Current Operating System'), isFolder=False)

    build_menu_label = 'Build Menu' if NUM_BUILDS == 0 or buildfile in ('', 'http://CHANGEME') else f'Build Menu ({NUM_BUILDS} Builds)'
    add_dir(COLOR2(build_menu_label), '', 1, addon_icon, addon_fanart, COLOR2(local_string(30001)), isFolder=True)
    
    add_dir(COLOR2(local_string(30002)), '', 5, addon_icon, addon_fanart, COLOR2(local_string(30011)), isFolder=True)
    add_dir(COLOR2(local_string(30119)), '', 36, addon_icon, addon_fanart, COLOR2(local_string(30119)), isFolder=True)
    add_dir(COLOR2(local_string(30013)), '', 34, addon_icon, addon_fanart, COLOR2(local_string(30014)), isFolder=False)
    
    if videos_url not in ('', 'http://', 'http://CHANGEME'):
        add_dir(COLOR2('Videos'), videos_url, 40, addon_icon, addon_fanart, COLOR2('Videos'), isFolder=True)

    if changelog_dir not in ['', 'http://', 'http://CHANGEME/'] and CURRENT_BUILD not in ['No Build Installed', 'No Build']:
        add_dir(COLOR2(f'View Changelog'), '', 35, addon_icon, addon_fanart, COLOR2(f'View the changelog for your installed build\n\nCurrent Build:  {CURRENT_BUILD} v{BUILD_VERSION}'), isFolder=False)

    add_dir(COLOR2('View Log'),'', 26, addon_icon,addon_fanart,COLOR2('View the Kodi Log'), isFolder=False)
    add_dir(COLOR2(local_string(30015)), '', 9, addon_icon, addon_fanart, COLOR2(local_string(30016)), isFolder=False)


def build_menu():
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmcplugin.setPluginCategory(HANDLE, local_string(30010))

    builds = load_builds_cache()

    if builds:
        xbmc.log("[709Wiz] Loaded builds from builds_cache.json", xbmc.LOGINFO)
    else:
        xbmc.log("[709Wiz] Builds cache unavailable - loading buildfile fallback", xbmc.LOGINFO)
        try:
            response = get_page(buildfile)
        except:
            xbmcgui.Dialog().notification(addon_name, 'No Build File Present!!', addon_icon, 3000)
            return

        builds = parse_builds_response(response)

    if not builds:
        xbmcgui.Dialog().notification(addon_name, 'No Builds Found!!', addon_icon, 3000)
        return

    for build in builds:
        name = build.get('name', local_string(30018))
        version = build.get('version', '')
        kodiversion = build.get('kodi')
        url = build.get('url', '')
        if setting("autozipsize") == "true":
            buildsize = build.get('size', '0MB')
        else:
            buildsize = ''
        if url.startswith('https://www.dropbox.com'):
            url = url.replace('dl=0', 'dl=1')
        icon = build.get('icon', addon_icon)
        fanart = build.get('fanart', addon_fanart)
        description = build.get('description', local_string(30019))
        preview = build.get('preview', None)

        if url.endswith('.xml') or url.endswith('.json') or url.endswith('.txt'):
            add_dir(COLOR2(name), url, 1, icon, fanart, COLOR2(description),
                    name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=True)

        elif '20' in kodi_ver and version == '' and kodiversion == 'K20':
            add_dir(COLOR2(f'{name}'), url, '', icon, fanart, description, name2=name, isFolder=False)

        elif '21' in kodi_ver and version == '' and kodiversion == 'K21':
            add_dir(COLOR2(f'{name}'), url, '', icon, fanart, description, name2=name, isFolder=False)

        elif '22' in kodi_ver and version == '' and kodiversion == 'K22':
            add_dir(COLOR2(f'{name}'), url, '', icon, fanart, description, name2=name, isFolder=False)
            
        elif '20' in kodi_ver and kodiversion == 'K20':
            if setting("autozipsize") == "true":
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version} / {buildsize})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            else:
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            if preview not in (None, '', 'http://', 'https://'):
                add_dir(COLOR1(local_string(30021) + ' ' + name + ' ' + local_string(30020) + ' ' + version),
                        preview, 2, icon, fanart, COLOR2(description), name2=name, version=version, isFolder=False)
                
        elif '21' in kodi_ver and kodiversion == 'K21':
            if setting("autozipsize") == "true":
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version} / {buildsize})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            else:
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            if preview not in (None, '', 'http://', 'https://'):
                add_dir(COLOR1(local_string(30021) + ' ' + name + ' ' + local_string(30020) + ' ' + version),
                        preview, 2, icon, fanart, COLOR2(description), name2=name, version=version, isFolder=False)
                
        elif '22' in kodi_ver and kodiversion == 'K22':
            if setting("autozipsize") == "true":
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version} / {buildsize})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            else:
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            if preview not in (None, '', 'http://', 'https://'):
                add_dir(COLOR1(local_string(30021) + ' ' + name + ' ' + local_string(30020) + ' ' + version),
                        preview, 2, icon, fanart, COLOR2(description), name2=name, version=version, isFolder=False)

        elif not any(x in kodiversion for x in kodi_versions):
            add_dir(COLOR2(f'{name} (v{version})'), url, 3, icon, fanart, description,
                    name2=name, version=version, isFolder=False)
            if preview not in (None, '', 'http://', 'https://'):
                add_dir(COLOR1(local_string(30021) + ' ' + name + ' ' + local_string(30020) + ' ' + version),
                        preview, 2, icon, fanart, COLOR2(description), name2=name, version=version, isFolder=False)
                

def submenu_maintenance():
    stats = quick_stats()

    packagesize   = stats["packagesize"]
    thumbnailsize = stats["thumbnailsize"]
    cleanup       = stats["cleanup"]
    buildsize     = stats["buildsize"]

    add_dir(COLOR1('<><> [B]Kodi Check-Up[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)

    if CURRENT_BUILD not in ['No Build Installed', 'No Build']:
        add_dir(COLOR4(f'Total Build Size:  {buildsize}MB'),'','',addon_icon,addon_fanart, COLOR2('Total size on disk of your installed build'), isFolder=False)

    if cleanup > 400:
        add_dir(COLOR3(f'Clean Now:  {cleanup}MB'),'','',addon_icon,addon_fanart, COLOR2('Total clean-up is above 250MB'), isFolder=False)
    else:
        add_dir(COLOR4(f'Available to Clean:  {cleanup}MB'),'','',addon_icon,addon_fanart, COLOR2('Total data available to clean'), isFolder=False)

    add_dir(COLOR1('<><> Clean Kodi <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)

    add_dir(COLOR2(f'Clear All  [{cleanup}MB]'),'',31,addon_icon,addon_fanart,COLOR2('Clear both packages and thumbnail folders to free up space.'),isFolder=False)
    add_dir(COLOR2(f'Clear Packages  [{packagesize}MB]'),'',6,addon_icon,addon_fanart,COLOR2(local_string(30005)),isFolder=False)
    add_dir(COLOR2(f'Clear Thumbnails  [{thumbnailsize}MB]'),'',7,addon_icon,addon_fanart,COLOR2(local_string(30008)),isFolder=False)
    
    '''disk = quick_disk_stats()

    total_space = disk["total_space"]
    used_space  = disk["used_space"]
    free_space  = disk["free_space"]
    used_perc   = disk["used_perc"]
    free_perc   = disk["free_perc"]
    
    add_dir(COLOR1('<><> [B]System Check-Up[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)
    if total_space > 1024:
        add_dir(COLOR2(f'Capacity:  {round((total_space / 1024), 2)}GB  [100%]'), '', '', addon_icon, addon_fanart, COLOR2('Total size of your HDD/SSD'), isFolder=False)
    else:
        add_dir(COLOR2(f'Capacity:  {round((total_space))}MB'), '', '', addon_icon, addon_fanart, COLOR2('Total size of your HDD/SSD'), isFolder=False)
    if used_space > 1024:
        add_dir(COLOR2(f'Used Space:  {round((used_space / 1024), 2)}GB  [{used_perc}]'), '', '', addon_icon, addon_fanart, COLOR2('Total used HDD/SSD space'), isFolder=False)
    else:
        add_dir(COLOR2(f'Used Space:  {round((used_space))}MB  [{used_perc}]'), '', '', addon_icon, addon_fanart, COLOR2('Total used HDD/SSD space'), isFolder=False)
    if free_space > 1024:
        add_dir(COLOR2(f'Free Space:  {round((free_space / 1024), 2)}GB  [{free_perc}]'), '', '', addon_icon, addon_fanart, COLOR2('Total free HDD/SSD space'), isFolder=False)
    else:
        add_dir(COLOR2(f'Free Space:  {round((free_space))}MB  [{free_perc}]'), '', '', addon_icon, addon_fanart, COLOR2('Total free HDD/SSD space'), isFolder=False)'''


def submenu_tools():   
    add_dir(COLOR1('<><> [B]Backup & Restore[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)
    add_dir(COLOR2('Backup/Restore Build'),'',12,addon_icon,addon_fanart, COLOR2('Backup and Restore Build'))
    add_dir(COLOR2('Backup/Restore GUI & Skin Settings'),'',19,addon_icon,addon_fanart,COLOR2('Backup/Restore GUI & Skin Settings'))
    add_dir(COLOR2('Restore Kodi to Default (Fresh Start)'), '', 4, addon_icon, addon_fanart, COLOR2(local_string(30003)), isFolder=False)
    
    add_dir(COLOR1('<><> [B]Whitelist Add-ons[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)
    add_dir(COLOR2('Add To Whitelist'),'',11,addon_icon,addon_fanart,COLOR2(local_string(30064)), isFolder=False)
    add_dir(COLOR2('Remove From Whitelist'),'', 33, addon_icon,addon_fanart,COLOR2('Remove items from whitelist'), isFolder=False)
    
    add_dir(COLOR1('<><> [B]Wizard Tools[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)
    if chk_splash == None or chk_splash == 'true':
        add_dir(COLOR2('Disable Kodi Splash Screen'),'',29,addon_icon,addon_fanart,COLOR2(local_string(30113)),isFolder=False)
    else:
        add_dir(COLOR2('Enable Kodi Splash Screen'),'',29,addon_icon,addon_fanart,COLOR2(local_string(30113)),isFolder=False)
    if chk_skin_override():
        add_dir(COLOR2('Enable Skin Override Protection'),'',30,addon_icon,addon_fanart,COLOR2(local_string(30115)),isFolder=False)
    else:
        add_dir(COLOR2('Disable Skin Override Protection'),'',30,addon_icon,addon_fanart,COLOR2(local_string(30115)),isFolder=False)
    if '21' or '22' in kodi_ver:
        add_dir(COLOR2(local_string(30112)),'',8,addon_icon,addon_fanart,COLOR2(local_string(30009)),isFolder=False)
        add_dir(COLOR2('View Cache Settings'),'',75,addon_icon,addon_fanart,COLOR2('View video cache settings. Requires GUI settings level advanced or higher.'), isFolder=False)
    add_dir(COLOR2('Speedtest'),'',28,addon_icon,addon_fanart,COLOR2('Complete an Internet Speedtest'), isFolder=False)


def backup_restore():
    xbmcplugin.setPluginCategory(HANDLE, COLOR1('Backup/Restore'))
    add_dir(COLOR1('<><> [B]Backup/Restore[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''), isFolder=False)
    add_dir(COLOR2('Backup Build'),'',13,addon_icon,addon_fanart, COLOR2('Backup Build'), isFolder=False)
    add_dir(COLOR2('Restore Backup'),'',14, addon_icon,addon_fanart, COLOR2('Restore Backup'))
    add_dir(COLOR2('Change Backups Folder Location'),'',16,addon_icon,addon_fanart, COLOR2('Change the location where backups will be stored and accessed.'), isFolder=False)
    add_dir(COLOR2('Reset Backups Folder Location'),'',17,addon_icon,addon_fanart, COLOR2('Set the backup location to its default.'), isFolder=False)


def restore_gui_skin():
    add_dir(COLOR1('<><> [B]Backup/Restore GUI & Skin Settings[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''), isFolder=False)
    add_dir(COLOR2('Backup GUI & Skin Settings'),'',22,addon_icon,addon_fanart,COLOR2('Backup GUI & Skin Settings'), isFolder=False)
    add_dir(COLOR2('Restore GUI Settings'),'',23, addon_icon,addon_fanart, COLOR2('Restore Your GUI Settings'), isFolder=False)
    add_dir(COLOR2('Restore Skin Settings'),'',24, addon_icon,addon_fanart, COLOR2('Restore Your Skin Settings'), isFolder=False)
    add_dir(COLOR2('Restore Build Default GUI Settings'),'',20,addon_icon,addon_fanart,COLOR2('Restore GUI Settings'), isFolder=False)
    add_dir(COLOR2('Restore Build Default Skin Settings'),'',21, addon_icon,addon_fanart, COLOR2('Restore Skin Settings'), isFolder=False)
