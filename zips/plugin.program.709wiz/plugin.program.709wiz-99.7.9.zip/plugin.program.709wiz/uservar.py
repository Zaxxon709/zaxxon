'''#####-----Build File-----#####'''
buildfile = 'http://dr-venture.com/709/Wizard/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://dr-venture.com/709/Wizard/notify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'http://dr-venture.com/709/Wizard/changelogs/'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
