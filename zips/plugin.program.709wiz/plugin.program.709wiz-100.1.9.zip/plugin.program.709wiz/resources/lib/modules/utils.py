# -*- coding: utf-8 -*-
import os
import re
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import shutil
import hashlib
import time
import urllib.request
import xml.etree.ElementTree as ET
from inspect import getframeinfo, stack
from urllib.parse import quote_plus, unquote_plus
from .addonvar import addon_name, addon_version, addons_path, addon_icon, addon_id, addon_profile
import xbmcaddon

chk_interval = 60
translatePath = xbmcvfs.translatePath

#FLAM PB-Fix Paths
fenlt = "plugin.video.fenlight"
fenlt_addon = addons_path + translatePath('plugin.video.fenlight/')
fenlt_ver = os.path.join(addon_profile,'last_version.txt')

#FLAM Patch 1
fenlt_file_1 = addons_path + translatePath('plugin.video.fenlight/resources/lib/modules/kodi_utils.py')

#FLAM Patch 2
fenlt_file_2 = addons_path + translatePath('plugin.video.fenlight/resources/lib/modules/settings.py')

#FLAM Patch 3
fenlt_file_3 = addons_path + translatePath('plugin.video.fenlight/resources/lib/modules/sources.py')

#FLAM Patch 4
fenlt_file_4 = addons_path + translatePath('plugin.video.fenlight/resources/lib/modules/updater.py')


def add_dir(name,url,mode,icon,fanart,description, name2='', version='', kodi='', size='', addcontext=False,isFolder=True):
    u=sys.argv[0]+"?url="+quote_plus(url)+"&mode="+str(mode)+"&name="+quote_plus(name)+"&icon="+quote_plus(icon) +"&fanart="+quote_plus(fanart)+"&description="+quote_plus(description)+"&name2="+quote_plus(name2)+"&version="+quote_plus(version)+"&kodi="+quote_plus(kodi)+"&size="+quote_plus(size)
    liz=xbmcgui.ListItem(name)
    liz.setArt({'fanart':fanart,'icon':icon,'thumb':icon})
    liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "plotoutline": description})
    if addcontext:
        contextMenu = []
        liz.addContextMenuItems(contextMenu)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)

def play_video(name, url, icon, description):
    xbmcplugin.setPluginCategory(int(sys.argv[1]), name)
    url = unquote_plus(url)
    if url.endswith('.jpg') or url.endswith('.jpeg') or url.endswith('.png'):
        string = "ShowPicture(%s)" %url
        xbmc.executebuiltin(string)
        return
    liz = xbmcgui.ListItem(name)
    liz.setInfo('video', {'title': name, 'plot': description})
    liz.setArt({'thumb': icon, 'icon': icon})
    xbmc.Player().play(url, liz)

def GetParams():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

def get_mode():
    params=GetParams()
    mode = None
    try:
        mode=int(params["mode"])
    except:
        pass
    return mode

def Log(msg):
    fileinfo = getframeinfo(stack()[1][0])
    xbmc.log('*__{}__{}*{} Python file name = {} Line Number = {}'.format(
        addon_name, addon_version, msg, fileinfo.filename, fileinfo.lineno
    ), xbmc.LOGINFO)

def log(_text, _var):
    xbmc.log(f'{_text} = {str(_var)}', xbmc.LOGINFO)


#FLAM PLAYBACK/UPDATE FIX
def chk_pbfix(): # Check if wizard setting chk_pbfix is TRUE
    return xbmcaddon.Addon().getSetting('chk_pbfix') == 'true'

def notify(msg): # Display notifications if chk_pbfix is TRUE
    if chk_pbfix():
        xbmcgui.Dialog().notification(addon_name, msg, addon_icon, 3000)
    
def ensure_dir(path): # Ensure destination directory exists before writing files
    directory = os.path.dirname(path)
    if directory and not os.path.exists(directory):
        os.makedirs(directory)

def get_addon_version(addon_id): # Return the version of the installed addon by reading its addon.xml
    if not xbmcvfs.exists(fenlt_addon):
        return None
    try:
        addon_path = translatePath(f"special://home/addons/{addon_id}/addon.xml")
        if not xbmcvfs.exists(addon_path):
            return None

        tree = ET.parse(addon_path)
        root = tree.getroot()
        return root.attrib.get('version')
    except Exception as e:
        xbmc.log(f"[PB-FIX] Error reading addon version: {e}", xbmc.LOGERROR)
        return None

def load_last_version(): # Retreive previous version
    if not xbmcvfs.exists(fenlt_ver):
        return None
    with xbmcvfs.File(fenlt_ver) as f:
        return f.read()

def save_last_version(version): # Save current version
    ensure_dir(fenlt_ver)
    with xbmcvfs.File(fenlt_ver, 'w') as f:
        f.write(version)

def read_file(file_path): # Read a file
    with xbmcvfs.File(file_path, 'r') as f:
        return f.read().lstrip('\ufeff').replace('\r\n', '\n')

def write_file(file_path, data): # Write to a file
    with xbmcvfs.File(file_path, 'w') as f:
        f.write(data)

def patch_line(file_path, old_line, new_line, marker): # Replace lines of code
    if not xbmcvfs.exists(file_path):
        xbmc.log(f"[PB-FIX] Missing file: {file_path}", xbmc.LOGERROR)
        return False

    try:
        data = read_file(file_path)

        if marker in data:
            xbmc.log(f"[PB-FIX] {marker} already applied", xbmc.LOGINFO)
            return True

        if old_line not in data:
            xbmc.log(f"[PB-FIX] Could not find target line for {marker}", xbmc.LOGERROR)
            return False

        data = data.replace(old_line, new_line, 1)
        write_file(file_path, data)
        xbmc.log(f"[PB-FIX] {marker} applied", xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f"[PB-FIX] {marker} failed: {e}", xbmc.LOGERROR)
        return False

def compare_apply(): # Patch files
    if not xbmcvfs.exists(fenlt_addon):
        return None

    results = []

    # PB-FIX 1 - kodi_utils.py
    results.append(patch_line(
        fenlt_file_1,
        "\tfrom modules.settings import playback_key\n\tif not playback_key() in params:",
        "\t#PB-FIX 1\n\treturn True\n\tfrom modules.settings import playback_key\n\tif not playback_key() in params:",
        "PB-FIX 1"
    ))

    # PB-FIX 2 - settings.py
    results.append(patch_line(
        fenlt_file_2,
        "\treturn get_setting('fenlight.playback_key', '0')",
        "\t#PB-FIX 2\n\treturn 'media'",
        "PB-FIX 2"
    ))

    # PB-FIX 3 - sources.py
    results.append(patch_line(
        fenlt_file_3,
        "\t\tif not kodi_utils.external_playback_check(self.params): return",
        "\t\t#PB-FIX 3\n\t\t#if not kodi_utils.external_playback_check(self.params): return",
        "PB-FIX 3"
    ))

    # PB-FIX 4 - updater.py
    results.append(patch_line(
        fenlt_file_4,
        "\treturn string_alphanum_to_num(current_version) != string_alphanum_to_num(online_version)",
        "\t#PB-FIX 4\n\treturn False",
        "PB-FIX 4"
    ))

    if all(results):
        notify("FLAM Playback Fix Applied")
    else:
        notify("FLAM Playback Fix Failed - Check Log")

    return all(results)

def pbf(): # Apply fixes once at startup, then monitor for add-on updates
    if not xbmcvfs.exists(fenlt_addon):
        return

    ensure_dir(addon_profile)

    compare_apply()

    current_version = get_addon_version(fenlt)
    if current_version:
        save_last_version(current_version)

    monitor = xbmc.Monitor()
    start_time = time.time()
    max_runtime = 5 * 60  # 5-minute kill timer

    while not monitor.abortRequested():
        if time.time() - start_time > max_runtime:
            break

        xbmc.sleep(5000)

        new_version = get_addon_version(fenlt)
        last_version = load_last_version()

        if new_version and new_version != last_version:
            compare_apply()
            save_last_version(new_version)
