# resources/lib/buildsize_preload.py

import json
import os
import urllib.request
import xbmc
from .addonvar import headers, setting, translatePath, get_page
from .parser import XmlParser, TextParser
from uservar import buildfile
from concurrent.futures import ThreadPoolExecutor, as_completed

# Cache paths
old_cache_file = translatePath("special://profile/addon_data/plugin.program.709wiz/size_cache.json")
builds_cache_file = translatePath("special://profile/addon_data/plugin.program.709wiz/builds_cache.json")


def save_builds_cache(builds_list): # Save the entire builds list as JSON
    try:
        with open(builds_cache_file, "w", encoding="utf-8") as f:
            json.dump(builds_list, f, indent=2)
    except Exception as e:
        xbmc.log(f"[709Wiz] Failed to save builds cache: {e}", xbmc.LOGINFO)


def _parse_builds(response): # Parse builds from JSON/XML/TXT
    builds = []
    if '"name":' in response or "'name':" in response:
        builds = json.loads(response).get("builds", [])
    elif "<name>" in response:
        xml = XmlParser(response)
        builds = xml.parse_builds()
    elif "name=" in response or 'name="' in response:
        text = TextParser(response)
        builds = text.parse_builds()
    return builds


def _normalize_url(url: str) -> str: # Normalize Dropbox URLs for direct download
    if not url:
        return ""
    if url.startswith("https://www.dropbox.com"):
        return url.replace("dl=0", "dl=1")
    return url


def _fetch_size(url): # Fetch the size of a remote file using a Range GET request
    try:
        r_headers = headers.copy()
        r_headers["Range"] = "bytes=0-0"
        req = urllib.request.Request(url, headers=r_headers)
        f = urllib.request.urlopen(req, timeout=15)
        size = f.headers.get("Content-Range")
        if size:
            size = size.split("/")[-1]
        else:
            size = f.headers.get("Content-Length")
        if size:
            mb = f"{int(size) / float(1 << 20):.0f}MB"
            return url, mb
    except Exception as e:
        xbmc.log(f"[709Wiz] Size fetch failed for {url}: {e}", xbmc.LOGINFO)
    return url, None


def preload_builds_cache(max_workers: int = 8): # Cache the complete builds.xml file at startup, using version to determine updates
    if setting("autozipsize") != "true":
        xbmc.log("[709Wiz] Auto zip size disabled, skipping preload.", xbmc.LOGINFO)
        return

    xbmc.log("[709Wiz] Starting builds cache preload...", xbmc.LOGINFO)

    # Delete old cache file if it exists
    if os.path.exists(old_cache_file):
        try:
            os.unlink(old_cache_file)
            xbmc.log("[709Wiz] Old size_cache.json deleted.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[709Wiz] Failed to delete old cache: {e}", xbmc.LOGINFO)

    # Fetch the remote buildfile
    try:
        response = get_page(buildfile)
    except Exception as e:
        xbmc.log(f"[709Wiz] Failed to fetch buildfile: {e}", xbmc.LOGINFO)
        return

    builds = _parse_builds(response)
    if not builds:
        xbmc.log("[709Wiz] No builds found in buildfile.", xbmc.LOGINFO)
        return

    # Load previous cache to check versions
    cached_builds = []
    if os.path.exists(builds_cache_file):
        try:
            with open(builds_cache_file, "r", encoding="utf-8") as f:
                cached_builds = json.load(f)
        except Exception as e:
            xbmc.log(f"[709Wiz] Failed to read existing builds cache: {e}", xbmc.LOGINFO)
            cached_builds = []

    # Check if any version changed
    version_changed = False
    cached_versions = {b.get("url"): b.get("version") for b in cached_builds}
    for build in builds:
        url = _normalize_url(build.get("url", ""))
        if not url:
            continue
        if cached_versions.get(url) != build.get("version"):
            version_changed = True
            break

    if not version_changed:
        xbmc.log("[709Wiz] Builds cache up-to-date, no update required.", xbmc.LOGINFO)
        return

    # Save the new builds list to cache
    save_builds_cache(builds)
    xbmc.log("[709Wiz] Builds cache updated.", xbmc.LOGINFO)

    # Optional: fetch sizes in background (like before)
    urls_to_fetch = [(b.get("url"), b.get("version")) for b in builds if b.get("url")]
    if not urls_to_fetch:
        return

    xbmc.log(f"[709Wiz] Preloading sizes for {len(urls_to_fetch)} builds...", xbmc.LOGINFO)
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {executor.submit(_fetch_size, url): (url, version) for url, version in urls_to_fetch}
        for future in as_completed(future_map):
            url, version = future_map[future]
            try:
                _, size_str = future.result()
            except Exception as e:
                xbmc.log(f"[709Wiz] Worker error for {url}: {e}", xbmc.LOGINFO)
                continue
            if size_str:
                # update size in cache file if desired
                for build in builds:
                    if build.get("url") == url:
                        build["size"] = size_str
    # Save updated sizes back to cache
    save_builds_cache(builds)
    xbmc.log("[709Wiz] Build sizes updated in cache.", xbmc.LOGINFO)
