# resources/lib/builds_preload.py

import json
import os
import urllib.request
import xbmc
from .addonvar import headers, setting, translatePath, get_page
from .parser import XmlParser, TextParser
from uservar import buildfile
from concurrent.futures import ThreadPoolExecutor, as_completed

# Cache paths
old_cache_file = translatePath("special://profile/addon_data/plugin.program.709wiz/size_cache.json")
builds_cache_file = translatePath("special://profile/addon_data/plugin.program.709wiz/builds_cache.json")


def save_builds_cache(builds_list): # Save the entire builds list as JSON
	try:
		os.makedirs(os.path.dirname(builds_cache_file), exist_ok=True)
		temp_file = builds_cache_file + ".tmp"
		with open(temp_file, "w", encoding="utf-8") as f:
			json.dump(builds_list, f, indent=2)
		os.replace(temp_file, builds_cache_file)
		return True
	except Exception as e:
		xbmc.log(f"[709Wiz] Failed to save builds cache: {e}", xbmc.LOGINFO)
		return False


def _parse_builds(response): # Parse builds from JSON/XML/TXT
	if isinstance(response, bytes):
		response = response.decode("utf-8-sig")
	if not isinstance(response, str):
		return []
	response = response.strip()
	if response.startswith("{") or response.startswith("["):
		parsed = json.loads(response)
		return parsed.get("builds", []) if isinstance(parsed, dict) else parsed
	if "<name>" in response:
		return XmlParser(response).parse_builds()
	if "name=" in response:
		return TextParser(response).parse_builds()
	return []


def _normalize_url(url: str) -> str: # Normalize Dropbox URLs for direct download
	if not url:
		return ""
	if url.startswith("https://www.dropbox.com"):
		return url.replace("dl=0", "dl=1")
	return url


def _fetch_size(url): # Fetch the size of a remote file using a Range GET request
	try:
		# Resolve redirects without counting a download on the NAS.
		# The statistics endpoint counts GET requests, not HEAD requests.
		resolved_url = url
		if url.startswith("https://709.tail3ee924.ts.net/download/"):
			head_req = urllib.request.Request(url, headers=headers.copy(), method="HEAD")
			with urllib.request.urlopen(head_req, timeout=15) as head_response:
				resolved_url = head_response.geturl()
			if resolved_url == url:
				raise ValueError("Download redirect did not resolve")

		r_headers = headers.copy()
		r_headers["Range"] = "bytes=0-0"
		req = urllib.request.Request(resolved_url, headers=r_headers)
		with urllib.request.urlopen(req, timeout=15) as response:
			content_range = response.headers.get("Content-Range")
			if content_range and "/" in content_range:
				size = content_range.rsplit("/", 1)[-1]
			elif response.status == 200:
				# Only trust Content-Length for a full response.
				size = response.headers.get("Content-Length")
			else:
				size = None
			if size and size != "*":
				return url, f"{int(size) / float(1 << 20):.0f}MB"
	except Exception as e:
		xbmc.log(f"[709Wiz] Size fetch failed for {url}: {e}", xbmc.LOGINFO)
	return url, None


def _build_key(build):
	# A URL and version together identify the ZIP whose size can be reused.
	return (_normalize_url(build.get("url", "")), build.get("version"))


def _without_cached_size(build):
	# Size is calculated locally, not supplied by the remote buildfile.
	return {key: value for key, value in build.items() if key != "size"}


def preload_builds_cache(max_workers: int = 8): # Cache the complete builds file at startup, detecting additions, removals and metadata changes
	if setting("autozipsize") != "true":
		xbmc.log("[709Wiz] Auto zip size disabled, skipping preload.", xbmc.LOGINFO)
		return

	xbmc.log("[709Wiz] Starting builds cache preload...", xbmc.LOGINFO)

	# Delete old cache file if it exists
	if os.path.exists(old_cache_file):
		try:
			os.unlink(old_cache_file)
			xbmc.log("[709Wiz] Old size_cache.json deleted.", xbmc.LOGINFO)
		except Exception as e:
			xbmc.log(f"[709Wiz] Failed to delete old cache: {e}", xbmc.LOGINFO)

	# Fetch the remote buildfile
	try:
		response = get_page(buildfile)
		builds = _parse_builds(response)
	except Exception as e:
		xbmc.log(f"[709Wiz] Failed to fetch or parse buildfile: {e}", xbmc.LOGINFO)
		return

	if not isinstance(builds, list) or not builds or not all(isinstance(b, dict) for b in builds):
		xbmc.log("[709Wiz] No valid builds found in buildfile; keeping existing cache.", xbmc.LOGINFO)
		return

	# Load previous cache to preserve sizes for unchanged ZIP files
	cached_builds = []
	if os.path.exists(builds_cache_file):
		try:
			with open(builds_cache_file, "r", encoding="utf-8") as f:
				cached_builds = json.load(f)
			if not isinstance(cached_builds, list):
				cached_builds = []
		except Exception as e:
			xbmc.log(f"[709Wiz] Failed to read existing builds cache: {e}", xbmc.LOGINFO)
			cached_builds = []

	# Preserve sizes when URL and version are unchanged.
	cached_sizes = {}
	for old in cached_builds:
		if isinstance(old, dict) and old.get("url") and old.get("size"):
			cached_sizes[_build_key(old)] = old["size"]

	# Compare the complete build list, excluding locally calculated sizes.
	# This also detects added/removed builds and metadata-only changes.
	old_metadata = [_without_cached_size(b) for b in cached_builds if isinstance(b, dict)]
	new_metadata = [_without_cached_size(b) for b in builds]
	metadata_changed = old_metadata != new_metadata

	urls_to_fetch = {}
	for build in builds:
		url, version = _build_key(build)
		if not url:
			continue
		key = (url, version)
		if key in cached_sizes:
			build["size"] = cached_sizes[key]
		else:
			# Fetch only new/changed ZIPs or sizes that previously failed.
			urls_to_fetch[url] = True

	if not metadata_changed and not urls_to_fetch:
		xbmc.log("[709Wiz] Builds cache up-to-date, no update required.", xbmc.LOGINFO)
		return

	# Save metadata first so new builds appear even if size requests fail.
	if metadata_changed:
		if save_builds_cache(builds):
			xbmc.log(f"[709Wiz] Builds cache updated ({len(builds)} entries).", xbmc.LOGINFO)

	# Fetch missing sizes concurrently; do not refetch unchanged ZIPs.
	if urls_to_fetch:
		xbmc.log(f"[709Wiz] Preloading sizes for {len(urls_to_fetch)} builds...", xbmc.LOGINFO)
		with ThreadPoolExecutor(max_workers=max(1, max_workers)) as executor:
			future_map = {executor.submit(_fetch_size, url): url for url in urls_to_fetch}
			for future in as_completed(future_map):
				url = future_map[future]
				try:
					_, size_str = future.result()
				except Exception as e:
					xbmc.log(f"[709Wiz] Worker error for {url}: {e}", xbmc.LOGINFO)
					continue
				if size_str:
					for build in builds:
						if _normalize_url(build.get("url", "")) == url and "size" not in build:
							build["size"] = size_str
		if save_builds_cache(builds):
			xbmc.log("[709Wiz] Build sizes updated in cache.", xbmc.LOGINFO)
