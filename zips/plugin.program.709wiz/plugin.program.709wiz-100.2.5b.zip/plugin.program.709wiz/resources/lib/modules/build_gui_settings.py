"""Apply build-specific Kodi GUI settings, preserving other existing settings."""
import json
import re
from pathlib import Path
from xml.etree import ElementTree as ET
import xbmc
import xbmcvfs

_CONFIG = Path(__file__).with_name('build_gui_settings.json')


def expected_gui_version():
    version = xbmc.getInfoLabel('System.BuildVersion') or ''
    match = re.match(r'\s*(\d+)', version)
    if not match:
        xbmc.log('[7o9 Wizard] Unknown Kodi version; GUI format unchanged: ' + version, xbmc.LOGWARNING)
        return None
    major = int(match.group(1))
    if major == 21:
        return '2'
    if major != 22:
        xbmc.log('[7o9 Wizard] Unsupported Kodi version for GUI format: ' + version, xbmc.LOGWARNING)
        return None
    rc = re.search(r'\bRC[\s._-]*(\d+)', version, re.I)
    if rc:
        return '4' if int(rc.group(1)) >= 2 else '2'
    if re.search(r'ALPHA|BETA', version, re.I):
        return '2'
    return '4'


def _settings_for(build_name):
    try:
        with _CONFIG.open(encoding='utf-8') as stream:
            config = json.load(stream)
        return config.get(build_name, {})
    except (OSError, ValueError) as exc:
        xbmc.log('[7o9 Wizard] Cannot read build GUI configuration: ' + str(exc), xbmc.LOGERROR)
        return {}


def prepare_gui_xml(build_name, path):
    """Patch the extracted build GUI file. Do not create a partial GUI file."""
    path = Path(path)
    if not path.is_file():
        xbmc.log('[7o9 Wizard] Build guisettings.xml not found: ' + str(path), xbmc.LOGWARNING)
        return False
    try:
        tree = ET.parse(str(path))
        root = tree.getroot()
        if root.tag != 'settings':
            raise ValueError('Unexpected root: ' + root.tag)
        fmt = expected_gui_version()
        if fmt is None:
            return False
        root.set('version', fmt)
        for key, value in _settings_for(build_name).items():
            setting = root.find("./setting[@id='%s']" % key)
            if setting is None:
                setting = ET.SubElement(root, 'setting', {'id': key})
            setting.text = str(value)
            setting.attrib.pop('default', None)
        # Write to a temporary file, then atomically replace the extracted XML.
        tmp = path.with_name(path.name + '.709tmp')
        tree.write(str(tmp), encoding='utf-8', xml_declaration=True)
        tmp.replace(path)
        xbmc.log('[7o9 Wizard] Prepared GUI settings for ' + build_name + ' (format ' + fmt + ')', xbmc.LOGINFO)
        return True
    except (OSError, ValueError, ET.ParseError) as exc:
        xbmc.log('[7o9 Wizard] Failed preparing GUI settings: ' + str(exc), xbmc.LOGERROR)
        return False


def apply_build_gui_settings(build_name, path):
    """Apply live values before force-close and reassert the extracted XML values."""
    settings = _settings_for(build_name)
    for key, value in settings.items():
        request = {'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.SetSettingValue',
                   'params': {'setting': key, 'value': value}}
        try:
            result = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
            if 'error' in result:
                xbmc.log('[7o9 Wizard] JSON-RPC failed for %s: %s' % (key, result['error']), xbmc.LOGWARNING)
        except Exception as exc:
            xbmc.log('[7o9 Wizard] JSON-RPC error for %s: %s' % (key, exc), xbmc.LOGWARNING)
    # Force-close does not flush Kodi's in-memory settings; preserve the intended XML.
    prepare_gui_xml(build_name, path)
