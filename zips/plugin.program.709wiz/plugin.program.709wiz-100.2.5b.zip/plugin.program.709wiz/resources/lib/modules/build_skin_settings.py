"""Apply build-specific Kodi settings and retry after the forced restart."""
import json
import os
from pathlib import Path
import xbmc
import xbmcaddon
import xbmcvfs

_CONFIG = Path(__file__).with_name('build_skin_settings.json')
_PENDING = Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.program.709wiz/pending_build_settings.json'))


def _rpc(method, params):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params})))
    if 'error' in result:
        raise RuntimeError(str(result['error']))
    return result.get('result')


def _apply_gui(config):
    # Skin first: a skin switch can reset theme, colors and font.
    for key in ('lookandfeel.skin', 'lookandfeel.skintheme', 'lookandfeel.skincolors', 'lookandfeel.font', 'videoscreen.screenmode'):
        value = config[key]
        try:
            _rpc('Settings.SetSettingValue', {'setting':key,'value':value})
            actual = _rpc('Settings.GetSettingValue', {'setting':key})
            if not isinstance(actual, dict) or actual.get('value') != value:
                xbmc.log('[7o9 Wizard] GUI setting verification mismatch %s: %r' % (key,actual),xbmc.LOGWARNING)
            else:
                xbmc.log('[7o9 Wizard] Applied %s=%s' % (key,value),xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log('[7o9 Wizard] Could not apply %s=%s: %s' % (key,value,exc),xbmc.LOGWARNING)


def stage_build_settings(name, version, installed_date):
    with _CONFIG.open(encoding='utf-8') as f:
        configs=json.load(f)
    if name not in configs:
        xbmc.log('[7o9 Wizard] No GUI preset for build %s' % name,xbmc.LOGWARNING)
        return
    payload={'buildname':name,'buildversion':str(version),'buildinstalled':installed_date,'gui':configs[name]}
    _PENDING.parent.mkdir(parents=True,exist_ok=True)
    temporary=_PENDING.with_suffix('.tmp')
    with temporary.open('w',encoding='utf-8') as f:
        json.dump(payload,f,indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(str(temporary),str(_PENDING))
    # Best effort now; the durable pending file makes the next startup retry possible.
    _apply_gui(payload['gui'])


def apply_pending_build_settings():
    if not _PENDING.is_file():
        return False
    try:
        with _PENDING.open(encoding='utf-8') as f:
            payload=json.load(f)
        addon=xbmcaddon.Addon('plugin.program.709wiz')
        for key in ('buildname','buildversion','buildinstalled'):
            addon.setSetting(key,str(payload[key]))
        addon.setSetting('update_passed','false')
        addon.setSetting('firstrun','true')
        _apply_gui(payload['gui'])
        # Clear only after successful processing; individual JSON-RPC failures are logged.
        _PENDING.unlink()
        xbmc.log('[7o9 Wizard] Reapplied pending build settings for %s' % payload['buildname'],xbmc.LOGINFO)
        return True
    except Exception as exc:
        xbmc.log('[7o9 Wizard] Pending build settings retry failed: %s' % exc,xbmc.LOGERROR)
        return False
