# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import xml.etree.ElementTree as ET
import urllib.request
import urllib.error
import socket
import os


# =====================================================================
#   URL CHECKING
# =====================================================================

def fetch_detailed(url, timeout=5):
    if not url:
        return False, "No URL"

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "KodiRepoChecker"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            code = r.getcode()
            if not (200 <= code < 400):
                return False, f"HTTP {code}"

            content = r.read()
            if not content:
                return False, "Empty reply"

    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code}"
    except urllib.error.URLError as e:
        return False, f"URL error: {e.reason}"
    except socket.timeout:
        return False, "Timeout"
    except Exception as e:
        return False, f"Exception: {e}"

    try:
        text = content.decode("utf-8", "ignore")
    except Exception:
        text = str(content)

    if "<html" in text.lower():
        return False, "HTML error page"

    try:
        root = ET.fromstring(text)
    except Exception as e:
        return False, f"XML error: {e}"

    if root.tag.lower() not in ("addons", "addon"):
        return False, f"Unexpected root: {root.tag}"

    return True, "OK"


# =====================================================================
#   REPOSITORY PARSING
# =====================================================================

def extract_all_info_urls(addon_xml_path):
    urls = []

    try:
        tree = ET.parse(addon_xml_path)
        root = tree.getroot()

        for ext in root.findall("extension"):
            if ext.get("point") != "xbmc.addon.repository":
                continue

            for d in ext.findall("dir"):
                info = d.findtext("info")
                if info:
                    urls.append(info.strip())

            fallback = ext.findtext("info")
            if fallback:
                urls.append(fallback.strip())

    except Exception as e:
        xbmc.log(f"[RepoChk] Error parsing addon.xml: {e}", xbmc.LOGERROR)

    # Remove duplicates
    seen = set()
    cleaned = []
    for u in urls:
        if u not in seen:
            seen.add(u)
            cleaned.append(u)

    return cleaned


def get_installed_repositories():
    repos = {}
    addons_dir = xbmcvfs.translatePath("special://home/addons")

    folders, _ = xbmcvfs.listdir(addons_dir)

    for addon_id in folders:
        addon_xml = os.path.join(addons_dir, addon_id, "addon.xml")
        if not xbmcvfs.exists(addon_xml):
            continue

        mirrors = extract_all_info_urls(addon_xml)
        if mirrors:
            repos[addon_id] = mirrors

    return repos


# =====================================================================
#   RECHECK SINGLE
# =====================================================================

def recheck_single_repo(url_info_list):

    updated = []
    first_ok = False

    for idx, (url, _, _) in enumerate(url_info_list):
        ok, reason = fetch_detailed(url)
        updated.append((url, ok, reason))
        if idx == 0:
            first_ok = ok

    if not first_ok:
        status_color = "red"
    else:
        fails = [u for u in updated if not u[1]]
        status_color = "lightgreen" if len(fails) == 0 else "gold"

    return first_ok, updated, status_color


# =====================================================================
#   SORTING / FILTERING
# =====================================================================

def filter_repos(repo_data, mode):

    if mode == "all":
        return repo_data

    filtered = {}
    for repo_id, info in repo_data.items():
        c = info["status_color"]

        if mode == "green_only" and c == "lightgreen":
            filtered[repo_id] = info
        elif mode == "gold_only" and c == "gold":
            filtered[repo_id] = info
        elif mode == "red_only" and c == "red":
            filtered[repo_id] = info

    return filtered


def sort_repos_alpha(repo_data):
    return dict(sorted(repo_data.items(), key=lambda x: x[0].lower()))


# =====================================================================
#   DETAILS DIALOG
# =====================================================================

def show_repo_details(repo_id, repo_info):
    dialog = xbmcgui.Dialog()

    while True:
        items = []

        color = repo_info["status_color"]
        status_text = {
            "red": "Broken (first mirror failed)",
            "lightgreen": "Healthy (all mirrors OK)",
            "gold": "Partially broken (some mirrors failed)"
        }.get(color, "Unknown")

        items.append(f"[B]{repo_id}[/B]")
        items.append(f"[COLOR={color}]{status_text}[/COLOR]")
        items.append("[COLOR=grey]──────── Mirrors / URLs ────────[/COLOR]")

        for (url, ok, reason) in repo_info["urls"]:
            c = "lightgreen" if ok else "red"
            items.append(f"[COLOR={c}]{url}[/COLOR] - {reason}")

        items.append("[COLOR=yellow]Recheck this repository[/COLOR]")
        items.append("[COLOR=grey]Back[/COLOR]")

        choice = dialog.select(f"{repo_id} – Details", items)

        if choice == -1 or choice == len(items) - 1:
            return repo_info

        if "Recheck this repository" in items[choice]:
            first_ok, updated_urls, status = recheck_single_repo(repo_info["urls"])
            repo_info["urls"] = updated_urls
            repo_info["status_color"] = status
            repo_info["reachable"] = first_ok


# =====================================================================
#   EXPANDABLE LIST
# =====================================================================

def expandable_repo_dialog(filtered_repo_data, title_suffix=""):

    dialog = xbmcgui.Dialog()

    repos = sort_repos_alpha(filtered_repo_data)
    repo_count = len(repos)

    if not repos:
        xbmcgui.Dialog().ok("Repository Check", "No repositories in this category.")
        return

    while True:

        items = []

        items.append(f"[B]Total repositories:[/B] {repo_count}")

        repo_keys = list(repos.keys())

        for repo_id in repo_keys:
            c = repos[repo_id]["status_color"]
            items.append(f"[COLOR={c}]{repo_id}[/COLOR]")

        items.append("[COLOR=grey]Back[/COLOR]")

        choice = dialog.select(f"Repository Check — {title_suffix}", items)

        if choice == -1 or choice == len(items) - 1:
            return

        if choice >= 1:
            selected_repo = repo_keys[choice - 1]
            updated = show_repo_details(selected_repo, repos[selected_repo])
            repos[selected_repo] = updated


# =====================================================================
#   LOGGING
# =====================================================================

def save_results_to_log(repo_data):
    userdata_path = xbmcvfs.translatePath(
        "special://userdata/addon_data/plugin.program.709wiz/"
    )

    if not xbmcvfs.exists(userdata_path):
        xbmcvfs.mkdirs(userdata_path)

    log_path = os.path.join(userdata_path, "repository_check.log")

    lines = []
    lines.append("Repository Check Results")
    lines.append("========================")
    lines.append("")

    for repo_id, info in sort_repos_alpha(repo_data).items():
        c = info["status_color"]
        status_text = {
            "red": "BROKEN",
            "lightgreen": "WORKING",
            "gold": "PARTIALLY BROKEN"
        }.get(c, "UNKNOWN")

        lines.append(f"{repo_id} - {status_text}")
        for (url, ok, reason) in info["urls"]:
            prefix = "  [OK] " if ok else "  [FAIL] "
            lines.append(f"{prefix}{url}  -- {reason}")
        lines.append("")

    try:
        f = xbmcvfs.File(log_path, "w")
        f.write("\n".join(lines))
        f.close()
        xbmcgui.Dialog().ok("Repository Check", "Results saved to repository_check.log")
    except Exception as e:
        xbmcgui.Dialog().ok("Repository Check", f"Log save failed:\n{e}")


# =====================================================================
#   REMOVE BROKEN
# =====================================================================

def _remove_tree(path):
    if not xbmcvfs.exists(path):
        return

    dirs, files = xbmcvfs.listdir(path)

    for f in files:
        xbmcvfs.delete(os.path.join(path, f))

    for d in dirs:
        _remove_tree(os.path.join(path, d))

    xbmcvfs.rmdir(path)


def remove_broken_repos(repo_data):

    addons_root = xbmcvfs.translatePath("special://home/addons")
    broken = [rid for rid, info in repo_data.items() if info["status_color"] == "red"]

    if not broken:
        xbmcgui.Dialog().ok("Repository Check", "No broken repositories to remove.")
        return

    names_str = "\n".join(broken)

    yes = xbmcgui.Dialog().yesno(
        "Remove Broken Repositories",
        "The following repositories will be removed:\n\n" +
        names_str +
        "\n\nContinue?",
        nolabel="Cancel",
        yeslabel="Remove"
    )

    if not yes:
        return

    removed, failed = [], []

    for repo_id in broken:
        repo_path = os.path.join(addons_root, repo_id)
        try:
            _remove_tree(repo_path)
            removed.append(repo_id)
        except Exception:
            failed.append(repo_id)

    msg = []
    if removed:
        msg.append("[B]Removed:[/B]")
        msg.extend(removed)
        msg.append("")
    if failed:
        msg.append("[B]Failed to remove:[/B]")
        msg.extend(failed)

    xbmcgui.Dialog().ok("Repository Check", "\n".join(msg))

    restart_now = xbmcgui.Dialog().yesno(
        "Restart Recommended",
        "Kodi must restart to fully apply changes.\n\nForce close now?",
        nolabel="Restart Later",
        yeslabel="Force Close"
    )

    if restart_now:
        xbmc.executebuiltin("Quit")


# =====================================================================
#   MAIN MENU (WITH COLOR GUIDE)
# =====================================================================

def repo_main_menu(repo_data):

    dialog = xbmcgui.Dialog()

    count_all = len(repo_data)
    count_green = len(filter_repos(repo_data, "green_only"))
    count_gold = len(filter_repos(repo_data, "gold_only"))
    count_red  = len(filter_repos(repo_data, "red_only"))

    while True:

        choice = dialog.select(
            "Repository Check — Options",
            [
                # COLOR GUIDE (shown ONLY here)
                "[COLOR=grey]────────────── GUIDE  ──────────────[/COLOR]",
                "[COLOR=lightgreen] Healthy[/COLOR][TABS]1[/TABS][All mirrors OK]",
                "[COLOR=gold] Partial[/COLOR][TABS]1[/TABS][Some mirrors failed]",
                "[COLOR=red] Broken[/COLOR][TABS]1[/TABS][First mirror failed]",
                "[COLOR=grey]────────────────────────────────────[/COLOR]",

                # MENU OPTIONS
                f"1. View ALL repositories[TABS]2[/TABS][{count_all}]",
                f"2. View ONLY working[TABS]3[/TABS][{count_green}]",
                f"3. View ONLY partially broken[TABS]1[/TABS][{count_gold}]",
                f"4. View ONLY broken[TABS]3[/TABS][{count_red}]",
                "5. Save results to log file",
                "6. Remove all broken repositories",
                "7. Close",
            ]
        )

        if choice == -1 or choice == 11:
            return

        # Offset (legend takes indices 0–4)
        if choice == 5:
            expandable_repo_dialog(filter_repos(repo_data, "all"), "All")
        elif choice == 6:
            expandable_repo_dialog(filter_repos(repo_data, "green_only"), "Healthy")
        elif choice == 7:
            expandable_repo_dialog(filter_repos(repo_data, "gold_only"), "Partial")
        elif choice == 8:
            expandable_repo_dialog(filter_repos(repo_data, "red_only"), "Broken")
        elif choice == 9:
            save_results_to_log(repo_data)
        elif choice == 10:
            remove_broken_repos(repo_data)


# =====================================================================
#   MAIN ENTRY
# =====================================================================

def check_repos():

    repos = get_installed_repositories()
    total = len(repos)

    if total == 0:
        xbmcgui.Dialog().ok("Repository Check", "No repository addons found.")
        return

    progress = xbmcgui.DialogProgress()
    progress.create("Checking Repositories...", "Scanning repositories...")

    repo_data = {}

    for i, (repo_id, mirrors) in enumerate(repos.items(), 1):

        percent = int(i / float(total) * 100)
        progress.update(percent, f"Checking repository: {repo_id}")

        url_info_list = []
        for url in mirrors:
            ok, reason = fetch_detailed(url)
            url_info_list.append((url, ok, reason))

        first_ok = url_info_list[0][1] if url_info_list else False

        if not first_ok:
            status_color = "red"
        else:
            fails = [u for u in url_info_list if not u[1]]
            status_color = "lightgreen" if len(fails) == 0 else "gold"

        repo_data[repo_id] = {
            "reachable": first_ok,
            "status_color": status_color,
            "urls": url_info_list
        }

    progress.update(100, "Scan complete.")
    xbmc.sleep(400)
    progress.close()

    repo_main_menu(repo_data)

