import sys
import os
import xbmc
import xbmcplugin
import xbmcgui
import xbmcvfs
from .params import Params
from .play_video import play_video
from .repo_chk import check_repos

from uservar import notify_url, changelog_dir
from .menus import main_menu, build_menu, submenu_maintenance, submenu_tools, backup_restore, restore_gui_skin
from .authorize import authorize_menu, authorize_submenu
from .build_install import build_install
from .maintenance import fresh_start, clear_packages, clear_thumbnails, advanced_settings, splash, skin_override, skin_override_disable
from .whitelist import add_whitelist, remove_whitelist
from .addonvar import setting, setting_set, dialog, addon, addon_name, addon_icon, gui_save_default, gui_save_user, skin_gui, chk_splash, chk_skin_override, advancedsettings_xml, advancedsettings_blank, UPDATE_VERSION, BUILD_URL, BUILD_NAME
from .save_data import restore_gui, restore_skin, backup_gui_skin
from .backup_restore import backup_build, restore_menu, restore_build, get_backup_folder, reset_backup_folder
from .focus_settings import tmdbh_mdblist_api, rurl_settings_rd, rurl_settings_pm, rurl_settings_ad, am_accounts, am_manage, am_backup_restore

try:
    HANDLE = int(sys.argv[1])
except IndexError:
    HANDLE = 0

def router(paramstring):
    p = Params(paramstring)
    xbmc.log(str(p.get_params()), xbmc.LOGDEBUG)
    
    name = p.get_name()
    name2 = p.get_name2()
    version = p.get_version()
    url = p.get_url()
    mode = p.get_mode()
    icon = p.get_icon()
    description = p.get_description()
    
    xbmcplugin.setContent(HANDLE, 'files')

    if mode is None:
        main_menu()
    
    elif mode == 1:
        build_menu()
    
    elif mode == 2:
        play_video(name, url, icon, description)
    
    elif mode == 3:
        build_install(name, name2, version, url)
    
    elif mode == 4:
        fresh_start(standalone=True)
    
    elif mode == 5:
        submenu_maintenance()
    
    elif mode == 6:
        clear_packages()
        xbmc.executebuiltin('Container.Refresh()')
    
    elif mode == 7:
        clear_thumbnails()
        xbmc.executebuiltin('Container.Refresh()')
    
    elif mode == 8:
        advanced_settings()
    
    elif mode == 9:
        addon.openSettings()
    
    elif mode == 10:
        authorize_menu()
    
    elif mode == 11:
        add_whitelist()
    
    elif mode == 12:
        backup_restore()
    
    elif mode == 13:
        backup_build()
    
    elif mode == 14:
        restore_menu()
    
    elif mode == 15:
        restore_build(url)
    
    elif mode == 16:
        get_backup_folder()
    
    elif mode == 17:
        reset_backup_folder()
    
    elif mode == 18:
        os._exit(1)

    elif mode == 19:
        restore_gui_skin()

    elif mode == 20:
        restore_gui(gui_save_default)

    elif mode == 21:
        restore_skin(gui_save_default)

    elif mode == 22:
        backup_gui_skin(gui_save_user)
        xbmcgui.Dialog().notification(addon_name, 'Backup Complete!', addon_icon, 3000)

    elif mode == 23:
        restore_gui(gui_save_user)
        
    elif mode == 24:
        restore_skin(gui_save_user)
    
    elif mode == 25:
        xbmc.executebuiltin(url)
    
    elif mode == 26:
        from .quick_log import log_viewer
        log_viewer()
    
    elif mode == 27:
        authorize_submenu(name2, icon)
    
    elif mode == 28:
        from .speedtester.addon import run
        run()

    elif mode == 29:
        if chk_splash == None or chk_splash == 'true':
            ask = xbmcgui.Dialog().yesno(addon_name, 'Are you sure?', yeslabel='Yes', nolabel='No', defaultbutton=xbmcgui.DLG_YESNO_YES_BTN)
            if ask:
                splash('false') # Splash Disabled
                xbmc.executebuiltin('Container.Refresh()')
                xbmcgui.Dialog().notification(addon_name, 'Kodi Splash Screen Disabled!', addon_icon, 3000)
                xbmc.sleep(4000)
            else:
                quit()
        if chk_splash == 'false':
            ask = xbmcgui.Dialog().yesno(addon_name, 'Are you sure?', yeslabel='Yes', nolabel='No', defaultbutton=xbmcgui.DLG_YESNO_YES_BTN)
            if ask:
                splash('true') # Splash Enabled
                xbmc.executebuiltin('Container.Refresh()')
                xbmcgui.Dialog().notification(addon_name, 'Kodi Splash Screen Enabled!', addon_icon, 3000)
                xbmc.sleep(4000)
            else:
                quit()

    elif mode == 30:
        if chk_skin_override():
            if str(skin_gui) == 'skin.estuary':
                dialog.ok(addon_name, 'Your current skin is the default Kodi skin Estuary![CR][CR]Skin protection cannot be enabled for this skin. Please install a build and then enable skin protection.')
                quit()
            elif setting('skin_protection') == 'true':
                dialog.ok(addon_name, 'Skin protection is already enabled!')
                quit()
            else:
                ask = xbmcgui.Dialog().yesno(addon_name, 'Are you sure?', yeslabel='Yes', nolabel='No', defaultbutton=xbmcgui.DLG_YESNO_YES_BTN)
                if ask:
                    if not xbmcvfs.exists(advancedsettings_xml):
                        #If advancedsettings.xml does not exist copy blank file
                        shutil.copyfile(advancedsettings_blank, advancedsettings_xml)
                    else:
                        skin_override(skin_gui, advancedsettings_xml)
                        setting_set('skin_protection', 'true')
                        setting_set('saveadvanced', 'true')
                        xbmcgui.Dialog().notification(addon_name, 'Skin Protection Enabled!', addon_icon, 1000)
                        dialog.ok(addon_name, 'To save changes, please close Kodi, Press OK to force close Kodi')
                        os._exit(1)
        else: 
            ask = xbmcgui.Dialog().yesno(addon_name, 'Are you sure?', yeslabel='Yes', nolabel='No', defaultbutton=xbmcgui.DLG_YESNO_YES_BTN)
            if ask:
                skin_override_disable()
                setting_set('skin_protection', 'false')
                xbmcgui.Dialog().notification(addon_name, 'Skin Protection Disabled!', addon_icon, 1000)
                dialog.ok(addon_name, 'To save changes, please close Kodi, Press OK to force close Kodi')
                os._exit(1)

    elif mode == 31:
        clear_packages()
        xbmc.sleep(1000)
        clear_thumbnails()
        xbmc.executebuiltin('Container.Refresh()')

    elif mode == 32:
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmc.executebuiltin('Container.Refresh()')
        xbmcgui.Dialog().notification(addon_name, 'Checking for Add-on Updates!', addon_icon, 3000)

    elif mode == 33:
        remove_whitelist()

    elif mode == 34:
        if notify_url in ('http://CHANGEME', 'http://slamiousproject.com/wzrd/notify19.txt', ''):
            xbmcgui.Dialog().notification(addon_name, 'No Notifications to Display!!', addon_icon, 3000)
            sys.exit()
        from . import notify
        try:
            message = notify.get_notify()[1]
            notify.notification(message)
        except:
            pass

    elif mode == 35:
        if changelog_dir in ('http://CHANGEME', ''):
            xbmcgui.Dialog().notification(addon_name, 'No Changelog to Display!!', addon_icon, 3000)
            sys.exit()
        from . import notify
        message = notify.get_changelog()
        notify.notification_clog(message)

    elif mode == 36:
        submenu_tools()

    elif mode == 37:
        check_repos()

    elif mode == 40:
        from .play_video import video_menu
        video_menu()

    elif mode == 41:
        name = BUILD_NAME
        name2 = name
        if BUILD_URL.startswith('https://www.dropbox.com'):
           url = BUILD_URL.replace('dl=0', 'dl=1')
        else:
            url = BUILD_URL
        build_install(name, name2, UPDATE_VERSION, url)



#############################################################
#######################SHORTCUTS#############################
#############################################################


####Focus Add-on settings###
    elif mode == 50:
        tmdbh_mdblist_api()
    #ResolveURL
    elif mode == 51:
        rurl_settings_rd()
    elif mode == 52:
        rurl_settings_pm()
    elif mode == 53:
        rurl_settings_ad()
    # Account Manager
    elif mode == 62:
        am_accounts()
    elif mode == 63:
        am_manage()
    elif mode == 64:
        am_backup_restore()
    elif mode == 65:
        xbmc.executebuiltin('ActivateWindowAndFocus(skinsettings,9000,0,648,6480), True') #Logging

        
    #Video Cache Settings
    elif mode == 75:
        xbmc.executebuiltin('ActivateWindowAndFocus(servicesettings,9001,0,-194,0), True') #Video Caching

    xbmcplugin.endOfDirectory(HANDLE)
