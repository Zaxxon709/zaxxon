import base64
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import threading
import platform
import time
import json
import os
import re
from datetime import datetime
from xml.etree import ElementTree as ET
from uservar import buildfile, BUILDS
from urllib.request import Request, urlopen
from .parser import XmlParser, TextParser

addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon           = xbmcaddon.Addon(addon_id)
addon_info      = addon.getAddonInfo
addon_version   = addon_info('version')
addon_name      = addon_info('name')
addon_icon      = addon_info("icon")
addon_fanart    = addon_info("fanart")
addon_ver       = xbmc.getInfoLabel(f'System.AddonVersion({addon_id})')
translatePath   = xbmcvfs.translatePath
addon_profile   = translatePath(addon_info('profile'))
addon_path      = translatePath(addon_info('path'))    
setting         = addon.getSetting
setting_true    = lambda x: bool(True if setting(str(x)) == "true" else False)
setting_set     = addon.setSetting
local_string    = addon.getLocalizedString
CURRENT_BUILD   = setting('buildname')
CURRENT_VERSION = setting('buildversion')
BUILD_VERSION   = setting('buildversion')
home = translatePath('special://home/')
dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
xbmcPath=os.path.abspath(home)
addons_path = os.path.join(home, 'addons/')
user_path = os.path.join(home, 'userdata/')
data_path = os.path.join(user_path, 'addon_data/')
db_path = translatePath('special://database/')
addons_db = os.path.join(db_path, 'Addons33.db')
packages = os.path.join(addons_path, 'packages/')
zippath = os.path.join(packages, 'tempzip.zip')
resources = os.path.join(addon_path, 'resources/')
thumbnails = os.path.join(user_path, 'Thumbnails')
user_agent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'
headers = {'User-Agent': user_agent}
kodi_ver_ = str(xbmc.getInfoLabel("System.BuildVersion")[:2])
kodi_ver = str(xbmc.getInfoLabel("System.BuildVersion")[:4])
kodi_versions = ['K20', 'K21', 'K22']
sleep = xbmc.sleep
notify_file = os.path.join(addon_profile,'notify.txt')
texts_path = os.path.join(resources, 'texts/')
authorize = texts_path + 'authorize.json'
installed_date = str(datetime.now())[:-7]
inst_date = setting('buildinstalled')

#Backup Path for User GUI/Skin Settings
gui_save_path = translatePath(setting('backupfolder'))

#GUI Settings
gui_file = os.path.join(user_path, 'guisettings.xml')
gui_temp_dir = os.path.join(packages, 'gui_temp/')
gui_temp_file = os.path.join(gui_temp_dir, 'guisettings.xml')
gui_save_default = os.path.join(user_path, 'gui_settings/')
gui_save_user = os.path.join(gui_save_path, 'gui_settings_user/')

#Advanced Settings
advancedsettings_blank = os.path.join(resources, 'advancedsettings/advancedsettings.xml')
advancedsettings_xml =  os.path.join(user_path, 'advancedsettings.xml')
advancedsettings_backup =  os.path.join(packages, 'advancedsettings.xml')

#Add-on lists
vid_list = str(len([i for i in os.listdir(addons_path) if i.startswith('plugin.video')]))
prg_list = str(len([i for i in os.listdir(addons_path) if i.startswith('plugin.program')]))
repo_list = str(len([i for i in os.listdir(addons_path) if i.startswith('repo')]))
#add_up = xbmc.getInfoLabel('System.AddonUpdateCount')

#Build Stats
build_ver = xbmc.getInfoLabel('System.BuildVersion')
build_date = xbmc.getInfoLabel('System.BuildDate')
sys_arch = platform.architecture()[0]

#Maintenance Cache
CACHE_FILE     = translatePath('special://home/userdata/addon_data/%s/maint_cache.json' % addon_id)
CACHE_TIME     = 600   # 10 minutes


def isBase64(s):
    try:
        if base64.b64encode(base64.b64decode(s)).decode('utf8') == s:
            return True
        else:
            return False
    except:
        return False

def currSkin():
    return xbmc.getSkinDir()

def percentage(part, whole):
    return 100 * float(part)/float(whole)

def file_check(bfile):
    if isBase64(bfile):
        return base64.b64decode(bfile).decode('utf8')
    return bfile

def get_page(url):
       req = Request(file_check(url), headers = headers)
       return urlopen(req).read().decode('utf-8')

    
# Get Kodi Databases
def get_latest_db(db_type: str) -> str:
    highest_number = -1
    highest_file = None
    for file in os.listdir(db_path):
        if file.startswith(db_type) and file.endswith('.db'):
            try:
                number = int(file[len(db_type):file.index('.db')])
                if number > highest_number:
                    highest_number = number
                    highest_file = file
            except ValueError:
                pass
    if highest_file is not None:
        return os.path.join(db_path, highest_file)

textures_db = get_latest_db('Textures')
addons_db = get_latest_db('Addons')


# Kodi Splash Check 
def splash_chk():
    if xbmcvfs.exists(advancedsettings_xml):
        tree = ET.parse(advancedsettings_xml) #Parse Advancedsettings.xml
        root = tree.getroot()
        for splash in root.iter('splash'): #Check if splash is enabled/disabled
                value = splash.text
                return value
chk_splash = splash_chk()


# Skin Override via Advanced Settings
def chk_skin_override():
    if xbmcvfs.exists(advancedsettings_xml):
        tree = ET.parse(advancedsettings_xml) #Parse Advancedsettings.xml
        root = tree.getroot()
        if len(root.findall('lookandfeel')) == 0: #Check if skin settings exist
            return True
    else:
        return True


# Current Skin Name         
def get_skin_gui():
    #Get current skin name
    cur_skin = xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.GetSettingValue", "params":{"setting":"lookandfeel.skin"}, "id":1}')
    cur_skin = json.loads(cur_skin)
    skin = ''
    if 'result' in cur_skin and 'value' in cur_skin['result']:
            skin = cur_skin['result']['value']
            return skin
skin_gui = get_skin_gui()
cur_skin = xbmcaddon.Addon(skin_gui).getAddonInfo('name')


# Build Menu - Total Build Count
# All features read the shared cache; the startup service refreshes it once.
BUILDS_CACHE_FILE = translatePath('special://profile/addon_data/%s/builds_cache.json' % addon_id)


def load_builds_list():
	try:
		with open(BUILDS_CACHE_FILE, 'r', encoding='utf-8') as cache:
			builds = json.load(cache)
			return builds if isinstance(builds, list) else []
	except (OSError, ValueError, TypeError):
		return []


def count_builds(builds=None):
	if builds is None:
		builds = load_builds_list()
	return sum(1 for build in builds if build.get('version') and kodi_ver_ in (build.get('kodi') or ''))


NUM_BUILDS = count_builds()


def get_os():
    platforms = {
        'System.Platform.Windows': 'Windows',
        'System.Platform.Android': 'Android',
        'System.Platform.Linux': 'Linux',
        'System.Platform.OSX': 'macOS',
        'System.Platform.IOS': 'iOS'
    }

    for condition, name in platforms.items():
        if xbmc.getCondVisibility(condition):
            return name

    return 'Unknown'
os_name = get_os()


def get_kodi_codename():
    try:
        codename = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
        return {
            20: 'Nexus',
            21: 'Omega',
            22: 'Piers'
        }.get(codename, 'Unknown')
    except:
        return 'Unknown'
code_name = get_kodi_codename()


# Change Build Names Tool
def get_old_build():
       key = None
       for key in BUILDS:
           if key['Old Build'] == CURRENT_BUILD:
               builds = key
               break
           else:
               builds = {'Old Build': "Old Build_1"}
       for key, value in builds.items():
           if key == 'Old Build':
               old_build = value
               break
       return old_build
OLD_BUILD = get_old_build()

def get_new_build():
       if CURRENT_BUILD == OLD_BUILD:
           key = None
           for key in BUILDS:
               if key['Old Build'] == CURRENT_BUILD:
                   builds = key
                   break
           for key, value in builds.items():
               if key == 'New Build':
                   new_build = value
                   break
           return new_build
NEW_BUILD = get_new_build()

def get_update_details(builds=None):
	if builds is None:
		builds = load_builds_list()
	name = ''
	version = ''
	url = ''
	for build in builds:
		if build.get('name') == NEW_BUILD:
			name = str(build.get('name'))
			version = str(build.get('version'))
			url = build.get('url', '')
			break
		elif build.get('name') == CURRENT_BUILD:
			name = str(build.get('name'))
			version = str(build.get('version'))
			url = build.get('url', '')
			break
	return name, version, url


BUILD_NAME, UPDATE_VERSION, BUILD_URL = get_update_details()


# System Stats
def stats():
    systime = ['System.Uptime', 'System.TotalUptime', 'System.OSVersionInfo']
    data = []
    x = 0
    for item in systime:
        time = xbmc.getInfoLabel(item)
        y = 0
        while time == "Busy" and y < 10:
            time = xbmc.getInfoLabel(item)
            y += 1
            xbmc.sleep(200)
        data.append(time)
        x += 1
    uptime = data[0]
    total_uptime = data[1]
    os = data[2]
    os_info = "".join(re.split("\(|\)", os)[::2])
    return uptime, total_uptime, os_info
uptime, total_uptime, os_info = stats()


# Maintenance Stats with Caching
def fast_dir_size(path):
    """Fast recursive directory size using Kodi VFS."""
    total = 0
    try:
        dirs, files = xbmcvfs.listdir(path)
    except:
        return 0

    # File sizes
    for f in files:
        fp = os.path.join(path, f)
        try:
            total += xbmcvfs.Stat(fp).st_size()
        except:
            pass

    # Recurse into subfolders (skip heavy folders)
    for d in dirs:
        if d.lower() in ("cache", "temp"):
            continue
        total += fast_dir_size(os.path.join(path, d))

    return total


def load_cache():
    """Always load cache; get_maintenance_stats decides freshness."""
    if not xbmcvfs.exists(CACHE_FILE):
        return None

    try:
        with open(CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return None


def save_cache(data):
    """Save cache with epoch + human-readable local time."""
    data["time"] = time.time()
    data["date"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

    try:
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            f.write(json.dumps(data))
    except:
        xbmc.log("Wizard: Failed to save maintenance cache", xbmc.LOGINFO)


_refresh_running = False  # Prevent multiple threads


def refresh_stats_background():
    """
    Starts a background thread to refresh maintenance stats.
    Fully hardened: _refresh_running always resets (finally).
    Includes startup delay to allow Kodi thread scheduler to stabilize.
    """
    global _refresh_running

    if _refresh_running:
        return

    _refresh_running = True

    # Thread scheduler stabilization
    xbmc.sleep(250)

    def worker():
        global _refresh_running
        try:
            pkg = fast_dir_size(packages) / (1 << 20)
            thu = fast_dir_size(thumbnails) / (1 << 20)
            bld = fast_dir_size(home) / (1 << 20)

            stats = {
                "packagesize": round(pkg, 2),
                "thumbnailsize": round(thu, 2),
                "thumbs": round(thu, 2),
                "cleanup": round(pkg + thu, 2),
                "buildsize": round(bld, 2)
            }

            save_cache(stats)
            xbmc.log("Wizard: Background stats refreshed", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"Wizard: Stats refresh error - {e}", xbmc.LOGINFO)

        finally:
            # Hardened protection: ALWAYS reset
            _refresh_running = False

    threading.Thread(target=worker).start()


def get_maintenance_stats():
    stats = load_cache()
    refresh_stats_background()  # Always refresh on startup
    return stats or {
        "packagesize": 0.0,
        "thumbnailsize": 0.0,
        "thumbs": 0.0,
        "cleanup": 0.0,
        "buildsize": 0.0
    }


def quick_stats():
    """
    Instant stats for menus.
    ONLY reads cache.
    NEVER triggers background work.
    NEVER blocks.
    """
    stats = load_cache()
    if not stats:
        return {
            "packagesize": 0.0,
            "thumbnailsize": 0.0,
            "thumbs": 0.0,
            "cleanup": 0.0,
            "buildsize": 0.0
        }
    return stats


'''
# Disk Space Stats with Caching

DISK_CACHE_FILE = translatePath(
    'special://home/userdata/addon_data/%s/disk_cache.json' % addon_id
)
DISK_CACHE_TIME = 300  # 5 minutes

def load_disk_cache():
    if not xbmcvfs.exists(DISK_CACHE_FILE):
        return None
    try:
        with open(DISK_CACHE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if time.time() - data.get("time", 0) < DISK_CACHE_TIME:
            return data
    except:
        pass
    return None

def save_disk_cache(data):
    data["time"] = time.time()
    try:
        with open(DISK_CACHE_FILE, "w", encoding="utf-8") as f:
            f.write(json.dumps(data))
    except:
        xbmc.log("Wizard: Disk cache save failed", xbmc.LOGINFO)

def refresh_disk_stats_background():
    def worker():
        try:
            t = re.sub("[^0-9]", "", xbmc.getInfoLabel('System.TotalSpace'))
            u = re.sub("[^0-9]", "", xbmc.getInfoLabel('System.UsedSpace'))
            f = re.sub("[^0-9]", "", xbmc.getInfoLabel('System.FreeSpace'))

            data = {
                "total_space": round(int(float(t)), 3),
                "used_space":  round(int(float(u)), 3),
                "free_space":  round(int(float(f)), 3),
                "used_perc":   xbmc.getInfoLabel('System.UsedSpacePercent'),
                "free_perc":   xbmc.getInfoLabel('System.FreeSpacePercent')
            }

            save_disk_cache(data)
        except Exception as e:
            xbmc.log(f"Disk stats refresh error: {e}", xbmc.LOGINFO)

    threading.Thread(target=worker).start()

def get_disk_stats():
    stats = load_disk_cache()
    if stats:
        return stats

    # No cache → return empty & start background scan
    refresh_disk_stats_background()
    return {
        "total_space": 0,
        "used_space": 0,
        "free_space": 0,
        "used_perc": "0%",
        "free_perc": "0%"
    }

def quick_disk_stats():
    stats = load_disk_cache()
    if not stats:
        return {
            "total_space": 0,
            "used_space": 0,
            "free_space": 0,
            "used_perc": "0%",
            "free_perc": "0%"
        }
    return stats'''
