# resources/lib/buildsize_preload.py

import json
import os
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

import xbmc
import xbmcvfs

from uservar import buildfile
from .addonvar import headers, setting, translatePath, get_page  # reuse existing logic
from .parser import XmlParser, TextParser


# Same cache file path used in menus.py
cache_file = translatePath(
    "special://profile/addon_data/plugin.program.709wiz/size_cache.json"
)


def load_cache():
    if os.path.exists(cache_file):
        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_cache(cache_dict):
    try:
        with open(cache_file, "w", encoding="utf-8") as f:
            json.dump(cache_dict, f)
    except Exception as e:
        xbmc.log(f"[709Wiz] Failed to save size cache: {e}", xbmc.LOGINFO)


def _parse_builds(response):
    """
    Use the same detection logic as build_menu() to support json/xml/txt.
    """
    builds = []

    if '"name":' in response or "'name':" in response:
        builds = json.loads(response)["builds"]
    elif "<name>" in response:
        xml = XmlParser(response)
        builds = xml.parse_builds()
    elif "name=" in response or 'name="' in response:
        text = TextParser(response)
        builds = text.parse_builds()

    return builds


def _normalize_url(url: str) -> str:
    if not url:
        return ""
    if url.startswith("https://www.dropbox.com"):
        return url.replace("dl=0", "dl=1")
    return url


def _fetch_size(url):
    """
    Worker function used in threads.
    Returns (url, "XXMB") or (url, None) on failure.
    """
    try:
        r_headers = headers.copy()
        r_headers["Range"] = "bytes=0-0"

        req = urllib.request.Request(url, headers=r_headers)
        f = urllib.request.urlopen(req, timeout=15)

        size = f.headers.get("Content-Range")
        if size:
            size = size.split("/")[-1]
        else:
            size = f.headers.get("Content-Length")

        if size:
            mb = f"{int(size) / float(1 << 20):.0f}MB"
            return url, mb
    except Exception as e:
        xbmc.log(f"[709Wiz] Size fetch failed for {url}: {e}", xbmc.LOGINFO)

    return url, None


def preload_build_sizes(max_workers: int = 8):
    """
    Run at Kodi startup to pre-populate the size cache, using multi-threaded
    Range GET requests. Safe to call from service.
    """
    if setting("autozipsize") != "true":
        xbmc.log("[709Wiz] Auto zip size disabled, skipping preload.", xbmc.LOGINFO)
        return

    xbmc.log("[709Wiz] Preloading build sizes (multi-threaded)...", xbmc.LOGINFO)

    size_cache = load_cache()
    modified = False

    # Fetch buildfile
    try:
        response = get_page(buildfile)
    except Exception as e:
        xbmc.log(f"[709Wiz] Failed to fetch buildfile for preload: {e}", xbmc.LOGINFO)
        return

    builds = _parse_builds(response)
    if not builds:
        xbmc.log("[709Wiz] No builds found for preload.", xbmc.LOGINFO)
        return

    # Prepare URL list (normalized, unique, uncached)
    urls = []
    seen = set()

    for build in builds:
        url = _normalize_url(build.get("url", ""))

        # Skip separators / invalid URLs
        if not url or url == "http://":
            continue

        # Skip if already cached
        if url in size_cache:
            continue

        if url not in seen:
            seen.add(url)
            urls.append(url)

    if not urls:
        xbmc.log("[709Wiz] No new URLs to preload (cache up-to-date).", xbmc.LOGINFO)
        return

    xbmc.log(f"[709Wiz] Preloading sizes for {len(urls)} builds...", xbmc.LOGINFO)

    # Multi-threaded fetch
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {executor.submit(_fetch_size, url): url for url in urls}

        for future in as_completed(future_map):
            url = future_map[future]
            try:
                _, size_str = future.result()
            except Exception as e:
                xbmc.log(f"[709Wiz] Worker error for {url}: {e}", xbmc.LOGINFO)
                continue

            if size_str:
                size_cache[url] = size_str
                modified = True

    if modified:
        save_cache(size_cache)
        xbmc.log("[709Wiz] Build size preload complete (cache updated).", xbmc.LOGINFO)
    else:
        xbmc.log("[709Wiz] Build size preload complete (no changes).", xbmc.LOGINFO)
