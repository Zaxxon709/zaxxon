# -*- coding: utf-8 -*-
import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import shutil
import hashlib
import time
import urllib.request
import xml.etree.ElementTree as ET
from inspect import getframeinfo, stack
from urllib.parse import quote_plus, unquote_plus
from .addonvar import addon_name, addon_version, addons_path, addon_icon, addon_id, addon_profile
import xbmcaddon

chk_interval = 60
translatePath = xbmcvfs.translatePath

#PB Fix Paths
fenlt = "plugin.video.fenlight"
fenlt_addon = addons_path + translatePath('plugin.video.fenlight/')
fenlt_ver = os.path.join(addon_profile,'last_version.txt')

#Patch 1
fenlt_file_1 = addons_path + translatePath('plugin.video.fenlight/resources/lib/modules/settings.py')
fix_url_1 = "http://dr-venture.com/709/Wizard/fenlt_fix/fix/settings.py"
dflt_url_1 = "http://dr-venture.com/709/Wizard/fenlt_fix/dflt/settings.py"
fenlt_dflt_1 = os.path.join(addon_profile,'settings.py')

#Patch 2 (Optional)
fenlt_file_2 = addons_path + translatePath('plugin.video.fenlight/resources/lib/modules/kodi_utils.py')
fix_url_2 = "http://dr-venture.com/709/Wizard/fenlt_fix/fix/kodi_utils.py"
dflt_url_2 = "http://dr-venture.com/709/Wizard/fenlt_fix/dflt/kodi_utils.py"
fenlt_dflt_2 = os.path.join(addon_profile,'kodi_utils.py')

def chk_pbfix():
    return xbmcaddon.Addon().getSetting('chk_pbfix') == 'true'

def Log(msg):
    fileinfo = getframeinfo(stack()[1][0])
    xbmc.log('*__{}__{}*{} Python file name = {} Line Number = {}'.format(
        addon_name, addon_version, msg, fileinfo.filename, fileinfo.lineno
    ), xbmc.LOGINFO)

def notify(msg):
    if chk_pbfix():
        xbmcgui.Dialog().notification(addon_name, msg, addon_icon, 3000)

def ensure_dir(path):
    # Ensure destination directory exists before writing files
    directory = os.path.dirname(path)
    if directory and not os.path.exists(directory):
        os.makedirs(directory)

def dl_dflt_file(url, save_path):
    # Download default file
    ensure_dir(save_path)
    urllib.request.urlretrieve(url, save_path)

def dl_fix_file(url, dstn_path):
    if not xbmcvfs.exists(fenlt_addon):
        return None

    # Read fix file
    with urllib.request.urlopen(url) as response:
        data = response.read()

    # Write fix to the destination file (overwrite)
    with xbmcvfs.File(dstn_path, "wb") as file:
        file.write(data)

def get_addon_version(addon_id):
    # Return the version of the installed addon by reading its addon.xml
    if not xbmcvfs.exists(fenlt_addon):
        return None
    try:
        addon_path = translatePath(f"special://home/addons/{addon_id}/addon.xml")
        if not xbmcvfs.exists(addon_path):
            return None

        tree = ET.parse(addon_path)
        root = tree.getroot()
        return root.attrib.get('version')
    except Exception as e:
        xbmc.log(f"[PB-FIX] Error reading addon version: {e}", xbmc.LOGERROR)
        return None

def load_last_version():
    # Retreive previous version
    if not xbmcvfs.exists(fenlt_ver):
        return None
    with xbmcvfs.File(fenlt_ver) as f:
        return f.read()

def save_last_version(version):
    # Save current version
    ensure_dir(fenlt_ver)
    with xbmcvfs.File(fenlt_ver, 'w') as f:
        f.write(version)

def cleanup_defaults():
    # Remove downloaded default files after successful use
    for f in (fenlt_dflt_1, fenlt_dflt_2):
        try:
            if f and xbmcvfs.exists(f):
                xbmcvfs.delete(f)
        except Exception as e:
            xbmc.log(f"[PB-FIX] Cleanup failed for {f}: {e}", xbmc.LOGERROR)

def compare_files(file1, file2):
    # Compare two files
    try:
        with xbmcvfs.File(file1) as f1, xbmcvfs.File(file2) as f2:
            a = f1.read().lstrip('\ufeff').replace('\r\n', '\n').strip()
            b = f2.read().lstrip('\ufeff').replace('\r\n', '\n').strip()
            return a == b
    except Exception as e:
        xbmc.log(f"[PB-FIX] compare_files failed: {e}", xbmc.LOGERROR)
        return False

def has_pbfix_marker(fenlt_file):
    # Check for PB-FIX marker
    if not xbmcvfs.exists(fenlt_file):
        return False
    try:
        with xbmcvfs.File(fenlt_file) as f:
            return 'PB-FIX' in f.read()
    except Exception:
        return False

def compare_apply():
    # Delete old files if Fen Light is not installed
    if not xbmcvfs.exists(fenlt_addon):
        return None

    # Compare File 1
    if xbmcvfs.exists(fenlt_file_1) and xbmcvfs.exists(fenlt_dflt_1):
        xbmc.log(f"[PB-FIX] compare_files result: {compare_files(fenlt_file_1, fenlt_dflt_1)}",xbmc.LOGINFO)
        if compare_files(fenlt_file_1, fenlt_dflt_1):
            try:
                dl_fix_file(fix_url_1, fenlt_file_1)
                notify('Success - FLAM Patch 1 Applied!!')
                xbmc.sleep(3000)
            except Exception as e:
                notify('FLAM Patch 1 Failed!!')
                xbmc.sleep(3000)
                xbmc.log(str(e), xbmc.LOGERROR)
        elif has_pbfix_marker(fenlt_file_1):
            notify('FLAM File 1 Already Patched!!')
            xbmc.sleep(3000)
        else:
            notify('WARNING - FLAM File 1 Code Changed!!')
            xbmc.sleep(3000)

    # Compare File 2 (Optional)
    if xbmcvfs.exists(fenlt_file_2) and xbmcvfs.exists(fenlt_dflt_2):
        if compare_files(fenlt_file_2, fenlt_dflt_2):
            try:
                dl_fix_file(fix_url_2, fenlt_file_2)
                notify('Success - FLAM Patch 2 Applied!!')
                xbmc.sleep(3000)
            except Exception as e:
                notify('FLAM Patch 2 Failed!!')
                xbmc.sleep(3000)
                xbmc.log(str(e), xbmc.LOGERROR)
        elif has_pbfix_marker(fenlt_file_2):
            notify('FLAM File 2 Already Patched!!')
            xbmc.sleep(3000)
        else:
            notify('WARNING - FLAM File 2 Code Changed!!')
            xbmc.sleep(3000)

def pbf():
    # Ensure profile directory exists
    ensure_dir(addon_profile)

    # Initial default downloads
    try:
        dl_dflt_file(dflt_url_1, fenlt_dflt_1)
        dl_dflt_file(dflt_url_2, fenlt_dflt_2)
    except Exception as e:
        xbmc.log(f"[PB-FIX] Initial download failed: {e}", xbmc.LOGERROR)

    # Initial compare / apply
    compare_apply()

    # Cleanup defaults after initial use
    cleanup_defaults()

    # Check if addon updated 
    last_version = load_last_version()
    current_version = get_addon_version(fenlt)

    if current_version and last_version != current_version:
        compare_apply()
        save_last_version(current_version)
        cleanup_defaults()

    # Start monitoring loop to monitor for Fen Light updates (Checks every 5sec)
    monitor = xbmc.Monitor()
    start_time = time.time()
    max_runtime = 5 * 60  # 5-minute kill timer

    while not monitor.abortRequested():

        # Kill service after 5min
        if time.time() - start_time > max_runtime:
            break

        # Run every 5 seconds
        xbmc.sleep(5000)

        # Check if addon updated
        new_version = get_addon_version(fenlt)
        last_version = load_last_version()

        if new_version and new_version != last_version:

            # Download default files
            try:
                dl_dflt_file(dflt_url_1, fenlt_dflt_1)
                dl_dflt_file(dflt_url_2, fenlt_dflt_2)
            except Exception as e:
                xbmc.log(f"[PB-FIX] Monitor download failed: {e}", xbmc.LOGERROR)

            # Compare / apply patch
            compare_apply()

            # Update stored add-on version
            save_last_version(new_version)

            # Cleanup defaults after successful patch
            cleanup_defaults()

