# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcvfs
import sqlite3 as database
from urllib.parse import quote

# Max recent searches
MAX_HISTORY_ITEMS = 20

settings_path = xbmcvfs.translatePath("special://profile/addon_data/script.fentastic.helper/")
spath_database_path = xbmcvfs.translatePath("special://profile/addon_data/script.fentastic.helper/spath_cache.db")

class SPaths:
    def __init__(self, spaths=None):
        self.connect_database()
        if spaths is None:
            self.spaths = []
        else:
            self.spaths = spaths

    def connect_database(self):
        if not xbmcvfs.exists(settings_path):
            xbmcvfs.mkdir(settings_path)
        self.dbcon = database.connect(spath_database_path, timeout=20)
        self.dbcon.execute(
            "CREATE TABLE IF NOT EXISTS spath (spath_id INTEGER PRIMARY KEY AUTOINCREMENT, spath text)"
        )
        self.dbcur = self.dbcon.cursor()


    # -----------------------------------------------------------------------
    # Database helpers
    # -----------------------------------------------------------------------
    def add_spath_to_database(self, spath):
        self.dbcur.execute(
            "INSERT INTO spath (spath) VALUES (?)",
            (spath,),
        )
        self.dbcon.commit()

    def remove_spath_from_database(self, spath_id):
        self.dbcur.execute("DELETE FROM spath WHERE spath_id = ?", (spath_id,))
        self.dbcon.commit()

    def is_database_empty(self):
        self.dbcur.execute("SELECT COUNT(*) FROM spath")
        rows = self.dbcur.fetchone()[0]
        return rows == 0

    def remove_all_spaths(self):
        dialog = xbmcgui.Dialog()
        title = "FENtastic"
        prompt = (
            "Are you sure you want to clear all search history?\n"
            "Once cleared, these items cannot be recovered."
        )

        if not dialog.yesno(title, prompt):
            return

        # Clear database
        self.dbcur.execute("DELETE FROM spath")
        self.dbcur.execute("DELETE FROM sqlite_sequence WHERE name='spath'")
        self.dbcon.commit()

        # Clear search history skin strings
        self.apply_search_history_to_skin([])

        # Reset search-related status strings
        xbmc.executebuiltin("Skin.SetString(SearchInput,)")
        xbmc.executebuiltin("Skin.SetString(SearchInputEncoded,)")
        xbmc.executebuiltin("Skin.SetString(SearchInputTraktEncoded, 'none')")
        xbmc.executebuiltin("Skin.SetString(DatabaseStatus, 'Empty')")

        # Notify the user
        xbmc.executebuiltin(
            "Notification(FENtastic,Search history cleared!,3000)"
        )

        # Always return to HOME
        xbmc.executebuiltin("ActivateWindow(Home)")

        # Focus a home control after returning
        xbmc.sleep(300)
        xbmc.executebuiltin("SetFocus(9000)")

    def fetch_all_spaths(self):
        results = self.dbcur.execute(
            "SELECT * FROM spath ORDER BY spath_id DESC"
        ).fetchall()
        return results

    def check_spath_exists(self, spath):
        result = self.dbcur.execute(
            "SELECT spath_id FROM spath WHERE spath = ?", (spath,)
        ).fetchone()
        return result[0] if result else None


    # -----------------------------------------------------------------------
    # Skin / window helpers
    # -----------------------------------------------------------------------
    def apply_search_history_to_skin(self, active_spaths=None):
        if active_spaths is None:
            active_spaths = self.fetch_all_spaths()

        # Ensure we have a simple list of terms in newest-first order
        labels = [spath for _, spath in active_spaths]

        for index in range(MAX_HISTORY_ITEMS):
            slot = index + 1
            if index < len(labels):
                spath = labels[index]
                xbmc.executebuiltin(
                    f"Skin.SetString(SearchHistory.{slot},{spath})"
                )
            else:
                # Clear any remaining slots so they don't show stale values
                xbmc.executebuiltin(f"Skin.Reset(SearchHistory.{slot})")

    def update_settings_after_clear(self):
        #Called after clearing all history
        xbmc.executebuiltin("Skin.SetString(SearchInput,)")
        xbmc.executebuiltin("Skin.SetString(SearchInputEncoded,)")
        xbmc.executebuiltin("Skin.SetString(SearchInputTraktEncoded, 'none')")
        xbmc.executebuiltin("Skin.SetString(DatabaseStatus, 'Empty')")

        # If Search Results window is open, move focus to the 'New search'
        if xbmcgui.getCurrentWindowId() == 1121:
            xbmc.executebuiltin("SetFocus(27400)")


    # -----------------------------------------------------------------------
    # Entry points used by router.py
    # -----------------------------------------------------------------------
    def open_search_window(self):
        if self.is_database_empty():
            xbmc.executebuiltin("Skin.SetString(DatabaseStatus, 'Empty')")
            xbmc.executebuiltin("Skin.SetString(SearchInputTraktEncoded, 'none')")
            # Clear the visible history list
            self.apply_search_history_to_skin([])
            if xbmcgui.getCurrentWindowId() == 10000:
                xbmc.executebuiltin("ActivateWindow(1121)")
                xbmc.executebuiltin("SetFocus(27400)")
        else:
            # Make sure history strings are in sync with DB
            self.remake_search_history()
            xbmc.executebuiltin("Skin.Reset(DatabaseStatus)")
            xbmc.executebuiltin("Skin.SetString(SearchInput,)")
            xbmc.executebuiltin("Skin.SetString(SearchInputEncoded,)")
            xbmc.executebuiltin("Skin.SetString(SearchInputTraktEncoded, 'none')")

            if xbmcgui.getCurrentWindowId() == 10000:
                xbmc.executebuiltin("ActivateWindow(1121)")
                xbmc.executebuiltin("SetFocus(803)")

    def search_input(self, search_term=None):
            # Prompt user if no term provided
            if search_term is None or not str(search_term).strip():
                prompt = (
                    "Search"
                    if xbmcgui.getCurrentWindowId() == 10000
                    else "New Search"
                )
                keyboard = xbmc.Keyboard("", prompt, False)
                keyboard.doModal()
                if keyboard.isConfirmed():
                    search_term = keyboard.getText()
                    if not search_term or not search_term.strip():
                        return
                else:
                    return

            # Mark UI as busy/loading and clear any previous search strings
            xbmc.executebuiltin("Skin.SetString(SearchBusy,1)")
            xbmc.executebuiltin("Skin.SetString(DatabaseStatus,Loading)")
            xbmc.executebuiltin("Skin.SetString(SearchInput,)")
            xbmc.executebuiltin("Skin.SetString(SearchInputEncoded,)")
            xbmc.executebuiltin("Skin.SetString(SearchInputTraktEncoded,none)")

            # Normalise and encode
            search_term = search_term.strip()
            encoded_search_term = quote(search_term)

            if xbmcgui.getCurrentWindowId() == 10000:
                xbmc.executebuiltin("ActivateWindow(1121)")

            # Clear previous widgets/results
            xbmc.executebuiltin("Container(27001).Update()")
            xbmc.sleep(100)

            # Maintain newest-first history in the DB
            existing_spath = self.check_spath_exists(search_term)
            if existing_spath:
                self.remove_spath_from_database(existing_spath)
            self.add_spath_to_database(search_term)

            # Update history labels in the skin
            self.apply_search_history_to_skin()

            # Update search input strings used by widgets/providers
            xbmc.executebuiltin(
                f"Skin.SetString(SearchInputEncoded,{encoded_search_term})"
            )
            xbmc.executebuiltin(
                f"Skin.SetString(SearchInputTraktEncoded,{encoded_search_term})"
            )
            xbmc.executebuiltin(f"Skin.SetString(SearchInput,{search_term})")

            # Move focus to the results area
            xbmc.executebuiltin("SetFocus(2000)")

            # Keep spinner up for a short time so providers can update
            xbmc.sleep(5000)

            # Clear busy state so UI + new results become visible
            xbmc.executebuiltin("Skin.Reset(SearchBusy)")
            xbmc.executebuiltin("Skin.Reset(DatabaseStatus)")


    def re_search(self):
        """Triggered when selecting an item from the search history list.

        Uses the current ListItem.Label as the search term.
        """
        search_term = xbmc.getInfoLabel("ListItem.Label")
        if not search_term:
            return
        self.search_input(search_term)

    def remake_search_history(self):
        """Re-sync skin strings with the DB contents, remove duplicates,
        and trim to MAX_HISTORY_ITEMS."""
        active_spaths = self.fetch_all_spaths()

        # Remove duplicates - preserve newest-first
        seen = set()
        cleaned = []
        for spath_id, term in active_spaths:
            if term not in seen:
                seen.add(term)
                cleaned.append((spath_id, term))

        # Trim older entries beyond the max allowed
        trimmed = cleaned[:MAX_HISTORY_ITEMS]

        # Rewrite DB if required
        if len(trimmed) != len(active_spaths):
            # Clear DB
            self.dbcur.execute("DELETE FROM spath")
            # Insert cleaned list
            for _, term in trimmed:
                self.dbcur.execute("INSERT INTO spath (spath) VALUES (?)", (term,))
            self.dbcon.commit()

        # Update skin strings
        self.apply_search_history_to_skin(trimmed)
