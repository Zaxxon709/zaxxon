# -*- coding: utf-8 -*-
import os
import shutil
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import sqlite3
import xml.etree.ElementTree as ET

dialog = xbmcgui.Dialog()
translatePath = xbmcvfs.translatePath
addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(addon_id)
addon_info = addon.getAddonInfo
addon_path = translatePath(addon_info('path'))
addon_data = translatePath('special://profile/addon_data/')
addon_icon = translatePath('special://home/addons/script.fentastic.helper/resources/icon.png')

#Skin Backup/Restore Variables
db_dst_dir = xbmcvfs.translatePath("special://profile/addon_data/script.fentastic.helper/")
home = translatePath('special://home/')
user_path = os.path.join(home, 'userdata/')
data_path = os.path.join(user_path, 'addon_data/')
skin_path = translatePath('special://skin/')
skin = ET.parse(os.path.join(skin_path, 'addon.xml'))
root = skin.getroot()
skin_id = root.attrib['id']

#GUI Restore Variables
gui_save_path = os.path.join(home, 'backups/')
gui_save_user = os.path.join(gui_save_path, 'gui_bkup/')
gui_file = 'guisettings.xml'

#Menu/Widget Default Configs
dst_cfg = os.path.join(skin_path, 'xml/')
dst_db = os.path.join(addon_data, 'script.fentastic.helper/')

fen_cfg = os.path.join(skin_path, 'resources/default_configs/Fen_Light/menus_widgets/')
fen_db = os.path.join(skin_path, 'resources/default_configs/Fen_Light/database/')

umb_cfg = os.path.join(skin_path, 'resources/default_configs/Umbrella/menus_widgets/')
umb_db = os.path.join(skin_path, 'resources/default_configs/Umbrella/database/')

pov_cfg = os.path.join(skin_path, 'resources/default_configs/POV/menus_widgets/')
pov_db = os.path.join(skin_path, 'resources/default_configs/POV/database/')

tmdbh_cfg = os.path.join(skin_path, 'resources/default_configs/TMDbH/menus_widgets/')
tmdbh_db = os.path.join(skin_path, 'resources/default_configs/TMDbH/database/')


# -------------------------------------------------
# HELPERS
# -------------------------------------------------
#Open Kodi keyboard and return input
def get_keyboard_text(default=""):
    kb = xbmc.Keyboard(default, "Enter name for your backup")
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText().strip()
        return text if text else None
    return None

#Create directory if it doesn't exist
def ensure_dir(path):
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)

#Copy file
def copy_file(src, dst):
    try:
        ensure_dir(os.path.dirname(dst))
        xbmcvfs.copy(src, dst)
    except Exception as e:
        dialog.notification("Backup Error", str(e), xbmcgui.NOTIFICATION_ERROR, 3000)

# Check if an addon is installed
def addon_installed(addon_id):
    """Return True if addon is installed."""
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except:
        return False

# Copy all files from source to destination
def copy_all_files(src_dir, dst_dir):
    """
    Copy all files from src_dir to dst_dir.
    Overwrites existing files with the same name.
    """
    # Make sure destination exists
    os.makedirs(dst_dir, exist_ok=True)

    # Loop through items in source directory
    for item in os.listdir(src_dir):
        src_path = os.path.join(src_dir, item)
        dst_path = os.path.join(dst_dir, item)

        # Copy only files (skip subdirectories)
        if os.path.isfile(src_path):
            shutil.copy2(src_path, dst_path)
            
# Delete files starting with
def delete_files_starting_with(directory, prefix):
    """
    Delete all files in `directory` whose filenames start with
    """
    # Ensure directory ends with slash
    if not directory.endswith(("/", "\\")):
        directory += "/"

    # List the directory contents
    try:
        dirs, files = xbmcvfs.listdir(directory)
    except Exception as e:
        xbmc.log(f"Error reading directory: {e}", xbmc.LOGERROR)
        return

    # Loop through files and delete those starting with prefix
    for file_name in files:
        if file_name.startswith(prefix):
            full_path = os.path.join(directory, file_name)
            xbmcvfs.delete(full_path)

            
# -------------------------------------------------
# GUI BACKUP/RESTORE FUNCTION
# -------------------------------------------------
#Backup gui settings
def backup_gui(gui_save):
    if not os.path.exists(gui_save_user):
        os.makedirs(gui_save_user)
    if os.path.exists(os.path.join(user_path, gui_file)) and os.path.exists(os.path.join(gui_save)):
        try:
            xbmcvfs.copy(os.path.join(user_path, gui_file), os.path.join(gui_save, gui_file))
        except Exception as e:
            xbmc.log('Failed to backup %s. Reason: %s' % (os.path.join(gui_save, gui_file), e), xbmc.LOGINFO)
    dialog.notification("FENtastic Plus", "Backup Complete", addon_icon, 3000)

#Restore GUI settings              
def restore_gui(gui_save):
    if os.path.exists(os.path.join(gui_save, gui_file)):
        try:
            xbmcvfs.copy(os.path.join(gui_save, gui_file), os.path.join(user_path, gui_file))
        except Exception as e:
            xbmc.log('Failed to restore %s. Reason: %s' % (os.path.join(user_path, gui_file), e), xbmc.LOGINFO)
    dialog.ok('FENtastic Plus', 'To save changes you now need to force close Kodi, Press OK to force close Kodi')
    os._exit(1)

    
# -------------------------------------------------
# MENU/WIDGET BACKUP FUNCTION
# -------------------------------------------------
def backup_config():
    backup_name = get_keyboard_text()
    if not backup_name:
        dialog.ok("Backup Canceled", "No backup name was entered.")
        return

    base_backup_dir = xbmcvfs.translatePath("special://home/backups/User_Configs/")
    backup_dir = os.path.join(base_backup_dir, backup_name)
    skin_backup_dir = os.path.join(backup_dir, "skin_files")
    skin_settings_backup_dir = os.path.join(backup_dir, "skin_settings")

    for d in (skin_backup_dir, skin_settings_backup_dir):
        ensure_dir(d)

    # Paths
    xml_dir = xbmcvfs.translatePath("special://skin/xml/")
    db_src = xbmcvfs.translatePath("special://profile/addon_data/script.fentastic.helper/cpath_cache.db")

    # Backup Menus/Widgets
    for file in xbmcvfs.listdir(xml_dir)[1]:
        if "script-fentastic" in file.lower():
            src = os.path.join(xml_dir, file)
            dst = os.path.join(skin_backup_dir, file)
            copy_file(src, dst)

    # Backup database
    if xbmcvfs.exists(db_src):
        copy_file(db_src, os.path.join(backup_dir, "cpath_cache.db"))

    # Backup skin settings   
    if os.path.exists(os.path.join(data_path, skin_id)) and os.path.exists(os.path.join(skin_settings_backup_dir)):
        try:
            shutil.copytree(os.path.join(data_path, skin_id), os.path.join(skin_settings_backup_dir, skin_id), dirs_exist_ok=True)
        except Exception as e:
                xbmc.log('Failed to backup %s. Reason: %s' % (os.path.join(skin_settings_backup_dir, skin_id), e), xbmc.LOGINFO)

    dialog.ok("Backup Completed", f"Backup saved as:   [COLOR=gold]{backup_name}[/COLOR]")


# -------------------------------------------------
# MENU/WIDGET RESTORE FUNCTION
# -------------------------------------------------
def restore_config():
    base_backup_dir = xbmcvfs.translatePath("special://home/backups/User_Configs/")
    if not xbmcvfs.exists(base_backup_dir):
        dialog.ok("Restore Error", "No backups directory found.")
        return

    # List backup folders
    folders = xbmcvfs.listdir(base_backup_dir)[0]

    if not folders:
        dialog.ok("Restore Error", "No backups available.")
        return

    # User selects a backup
    index = dialog.select("Choose Backup To Restore", folders)
    if index < 0:
        return

    selected_backup = folders[index]
    backup_path = os.path.join(base_backup_dir, selected_backup)
    skin_backup_path = os.path.join(backup_path, "skin_files/")
    skin_settings_backup_path = os.path.join(backup_path, "skin_settings/")

    # Restore skin XML files
    xml_dir = xbmcvfs.translatePath("special://skin/xml/")

    delete_files_starting_with(dst_cfg, 'script-fentastic')
    
    if xbmcvfs.exists(skin_backup_path):
        for file in xbmcvfs.listdir(skin_backup_path)[1]:
            src = os.path.join(skin_backup_path, file)
            dst = os.path.join(xml_dir, file)
            copy_file(src, dst)

    #Restore skin settings            
    if os.path.exists(os.path.join(data_path, skin_id)):
        try:
            shutil.copytree(os.path.join(skin_settings_backup_path, skin_id), os.path.join(data_path, skin_id), dirs_exist_ok=True)
        except Exception as e:
            xbmc.log('Failed to restore %s. Reason: %s' % (os.path.join(data_path, skin_id), e), xbmc.LOGINFO)

    #Restore database
    ensure_dir(db_dst_dir)
    db_src = os.path.join(backup_path, "cpath_cache.db")
    if xbmcvfs.exists(db_src):
        copy_file(db_src, os.path.join(db_dst_dir, "cpath_cache.db"))
    
    dialog.ok("Restore Complete", f"Restored backup:   [COLOR=gold]{selected_backup}[/COLOR]\n\nTo save changes you now need to force close Kodi, Press OK to force close Kodi")
    os._exit(1)


# -------------------------------------------------
# Enable All Main Menu Toggles
# -------------------------------------------------
def enable_all_home_menu_toggles():
    """
    Enables ALL home menu items based on the logic used in skinsettings.xml.
    Movies/TV use inverted logic; Custom1-6 use normal logic.
    """
    # Movies & TV shows
    inverted_settings = [
        "HomeMenuNoMoviesButton",
        "HomeMenuNoTVShowsButton",
    ]

    # Custom1–Custom6
    normal_settings = [
        "HomeMenuNoCustom1Button",
        "HomeMenuNoCustom2Button",
        "HomeMenuNoCustom3Button",
        "HomeMenuNoCustom4Button",
        "HomeMenuNoCustom5Button",
        "HomeMenuNoCustom6Button",
    ]

    # Music-Weather
    other_inverted_settings = [
        "HomeMenuNoMusicButton",
        "HomeMenuNoMusicVideoButton",
        "HomeMenuNoTVButton",
        "HomeMenuNoRadioButton",
        "HomeMenuNoPicturesButton",
        "HomeMenuNoVideosButton",
        "HomeMenuNoGamesButton",
        "HomeMenuNoWeatherButton",
    ]

    # Movies & TV Shows
    for setting in inverted_settings:
        is_set = xbmc.getCondVisibility(f"Skin.HasSetting({setting})")

        # If disabled. Enable it by resetting
        if is_set:
            xbmc.executebuiltin(f"Skin.Reset({setting})")
            xbmc.sleep(50)
        else:
            xbmc.log(f"Already ENABLED, skipping.", xbmc.LOGINFO)

    # CUSTOM 1–6
    for setting in normal_settings:
        is_set = xbmc.getCondVisibility(f"Skin.HasSetting({setting})")

        # If disabled. Enable it by setting true
        if not is_set:
            xbmc.executebuiltin(f"Skin.SetBool({setting})")
            xbmc.sleep(50)
        else:
            xbmc.log(f"Already ENABLED, skipping.", xbmc.LOGINFO)

    # Music - Weather
    for setting in other_inverted_settings:
        is_set = xbmc.getCondVisibility(f"Skin.HasSetting({setting})")
        
        # If enabled. Disable it by resetting
        if not is_set:
            xbmc.executebuiltin(f"Skin.SetBool({setting})")
            xbmc.sleep(50)
        else:
            xbmc.log(f"Already DISABLED, skipping.", xbmc.LOGINFO)


# -------------------------------------------------
# Main Menu Labels
# -------------------------------------------------
def load_all_menu_labels():
    """
    Reads all main menu labels from cpath_cache.db and assigns them
    to Skin.String() values for use in XML.
    """

    db_path = translatePath(
        "special://profile/addon_data/script.fentastic.helper/cpath_cache.db"
    )

    if not xbmcvfs.exists(db_path):
        return

    # DB main-menu key - Skin.String key - default label
    MENU_MAP = {
        "movie":   ("MenuMovieLabelDB",   "Movies"),
        "tvshow":  ("MenuTVShowLabelDB",  "TV Shows"),
        "custom1": ("MenuCustom1LabelDB", "Custom 1"),
        "custom2": ("MenuCustom2LabelDB", "Custom 2"),
        "custom3": ("MenuCustom3LabelDB", "Custom 3"),
        "custom4": ("MenuCustom4LabelDB", "Custom 4"),
        "custom5": ("MenuCustom5LabelDB", "Custom 5"),
        "custom6": ("MenuCustom6LabelDB", "Custom 6"),
    }

    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        for key, (skin_key, default_label) in MENU_MAP.items():
            # This matches rows like "movie.main_menu", "tvshow.main_menu", "custom1.main_menu", etc.
            setting_key = f"{key}.main_menu"

            cur.execute(
                "SELECT cpath_header FROM custom_paths WHERE cpath_setting = ? LIMIT 1",
                (setting_key,)
            )
            row = cur.fetchone()

            if row and row[0]:
                label = row[0]
                source = "DB"
            else:
                label = default_label
                source = "DEFAULT"

            safe = label.replace('"', "'")
            xbmc.executebuiltin(f'Skin.SetString({skin_key},"{safe}")')

        conn.close()

    except Exception as e:
        xbmc.log(f"DB Error loading menu labels: {e}", xbmc.LOGERROR)

        
# -------------------------------------------------
# Select Pre-Made Configurations
# -------------------------------------------------
def pre_config_dialog():
    """
    Shows only config modes for addons actually installed.
    """

    menu = []
    modes = []

    # Fen Light
    if addon_installed("plugin.video.fenlight"):
        menu.append("Fen Light")
        modes.append("Fen Light")

    # Umbrella
    if addon_installed("plugin.video.umbrella"):
        menu.append("Umbrella")
        modes.append("Umbrella")

    # TMDbH
    if addon_installed("plugin.video.themoviedb.helper") and any(addon_installed(a) for a in ["plugin.video.fenlight","plugin.video.umbrella","plugin.video.pov"]):
        menu.append("TMDb Helper")
        modes.append("TMDbH")
        
    # POV
    if addon_installed("plugin.video.pov"):
        menu.append("POV")
        modes.append("POV")
    
    # If none installed
    if not menu:
        xbmcgui.Dialog().ok("FENtastic Plus", "No supported addons are installed.\nNothing to configure.")
        return

    # Let the user choose
    choice = xbmcgui.Dialog().select("Choose Pre-Configuration", menu)

    if choice == -1:
        return  # Cancelled

    run_pre_config_mode(modes[choice])


def run_pre_config_mode(mode):
    # Ask the user to confirm before applying
    confirm = xbmcgui.Dialog().yesno(
        "FENtastic Plus",
        f"Are you sure you want to apply the '[COLOR gold]{mode}[/COLOR]' pre-configuration?\n\n"
        "This will overwrite your current menu/widgets configuration.",
        nolabel="No",
        yeslabel="Yes"
    )

    if not confirm:
        return
    
    if mode == "Fen Light":
        delete_files_starting_with(dst_cfg, 'script-fentastic')
        enable_all_home_menu_toggles()
        xbmc.executebuiltin('Skin.SetString(current_search_provider,"1")')
        copy_all_files(fen_cfg, dst_cfg)
        copy_all_files(fen_db, dst_db)

    elif mode == "Umbrella":
        delete_files_starting_with(dst_cfg, 'script-fentastic')
        enable_all_home_menu_toggles()
        xbmc.executebuiltin('Skin.SetString(current_search_provider,"2")')
        copy_all_files(umb_cfg, dst_cfg)
        copy_all_files(umb_db, dst_db)

    elif mode == "TMDbH":
        delete_files_starting_with(dst_cfg, 'script-fentastic')
        enable_all_home_menu_toggles()
        xbmc.executebuiltin('Skin.SetString(current_search_provider,"0")')
        copy_all_files(tmdbh_cfg, dst_cfg)
        copy_all_files(tmdbh_db, dst_db)

    elif mode == "POV":
        delete_files_starting_with(dst_cfg, 'script-fentastic')
        enable_all_home_menu_toggles()
        xbmc.executebuiltin('Skin.SetString(current_search_provider,"3")')
        copy_all_files(pov_cfg, dst_cfg)
        copy_all_files(pov_db, dst_db)

    load_all_menu_labels()
    xbmc.executebuiltin("ReloadSkin()")
    xbmcgui.Dialog().notification("FENtastic Plus", f"{mode} config applied!", addon_icon, 3000)
