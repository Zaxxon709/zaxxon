# -*- coding: utf-8 -*-

import os
import shutil
import xbmc
import xbmcgui
import xbmcvfs


def get_keyboard_text(default=""):
    #Open Kodi keyboard and return input
    kb = xbmc.Keyboard(default, "Enter name for your backup")
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText().strip()
        return text if text else None
    return None


def ensure_dir(path):
    #Create directory if it doesn't exist
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)


def copy_file(src, dst):
    #Copy file
    try:
        ensure_dir(os.path.dirname(dst))
        xbmcvfs.copy(src, dst)
    except Exception as e:
        xbmcgui.Dialog().notification("Backup Error", str(e), xbmcgui.NOTIFICATION_ERROR, 3000)


# =========================================================
# BACKUP FUNCTION
# =========================================================

def backup_fentastic_files():
    backup_name = get_keyboard_text()
    if not backup_name:
        xbmcgui.Dialog().ok("Backup Cancelled", "No backup name was entered.")
        return

    base_backup_dir = xbmcvfs.translatePath("special://home/backups/")
    backup_dir = os.path.join(base_backup_dir, backup_name)
    skin_backup_dir = os.path.join(backup_dir, "skin_files")

    ensure_dir(skin_backup_dir)

    # Paths
    xml_dir = xbmcvfs.translatePath("special://skin/xml/")
    db_src = xbmcvfs.translatePath(
        "special://profile/addon_data/script.fentastic.helper/cpath_cache.db"
    )

    # Copy matching XML files
    for file in xbmcvfs.listdir(xml_dir)[1]:
        if "script-fentastic" in file.lower():
            src = os.path.join(xml_dir, file)
            dst = os.path.join(skin_backup_dir, file)
            copy_file(src, dst)

    # Copy database file
    if xbmcvfs.exists(db_src):
        copy_file(
            db_src,
            os.path.join(backup_dir, "cpath_cache.db")
        )

    xbmcgui.Dialog().ok(
        "Backup Completed",
        f"Backup saved to:   [COLOR=gold]{backup_name}[/COLOR]"
    )


# =========================================================
# RESTORE FUNCTION
# =========================================================

def restore_fentastic_files():
    base_backup_dir = xbmcvfs.translatePath("special://home/backups/")
    if not xbmcvfs.exists(base_backup_dir):
        xbmcgui.Dialog().ok("Restore Error", "No backups directory found.")
        return

    # List backup folders
    folders = xbmcvfs.listdir(base_backup_dir)[0]

    if not folders:
        xbmcgui.Dialog().ok("Restore Error", "No backups available.")
        return

    # User selects a backup
    index = xbmcgui.Dialog().select("Choose Backup To Restore", folders)
    if index < 0:
        return

    selected_backup = folders[index]
    backup_path = os.path.join(base_backup_dir, selected_backup)
    skin_backup_path = os.path.join(backup_path, "skin_files/")

    # Restore skin XML files
    xml_dir = xbmcvfs.translatePath("special://skin/xml/")
    ensure_dir(xml_dir)

    if xbmcvfs.exists(skin_backup_path):
        for file in xbmcvfs.listdir(skin_backup_path)[1]:
            src = os.path.join(skin_backup_path, file)
            dst = os.path.join(xml_dir, file)
            copy_file(src, dst)

    # Restore DB
    db_dst_dir = xbmcvfs.translatePath(
        "special://profile/addon_data/script.fentastic.helper/"
    )
    ensure_dir(db_dst_dir)

    db_src = os.path.join(backup_path, "cpath_cache.db")
    if xbmcvfs.exists(db_src):
        copy_file(db_src, os.path.join(db_dst_dir, "cpath_cache.db"))
        xbmc.sleep(100)
        xbmc.executebuiltin("ReloadSkin()")
    
    xbmcgui.Dialog().ok(
        "Restore Complete",
        f"Restored backup:   [COLOR=gold]{selected_backup}[/COLOR]"
    )
