# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
import time

from acctmgr.modules import control
from acctmgr.modules import log_utils

def am_masters(): # AM Lite token variables
	acctmgr = xbmcaddon.Addon("script.module.acctmgr")
	rd_master_token = acctmgr.getSetting("realdebrid.token")
	pm_master_token = acctmgr.getSetting("premiumize.token")
	ad_master_token = acctmgr.getSetting("alldebrid.token")
	tb_master_token = acctmgr.getSetting("torbox.token")
	ed_master_token = acctmgr.getSetting("easydebrid.token")
	oc_master_token = acctmgr.getSetting("offcloud.token")
	en_master_user = acctmgr.getSetting("easynews.username")
	en_master_pass = acctmgr.getSetting("easynews.password")

	return rd_master_token, pm_master_token, ad_master_token, tb_master_token, ed_master_token, oc_master_token, en_master_user, en_master_pass

rd_master_token, pm_master_token, ad_master_token, tb_master_token, ed_master_token, oc_master_token, en_master_user, en_master_pass= am_masters()
					
def SyncManager():  # Auto-sync credentials to recently installed/supported/un-authorized addons
	try:
		if control.setting('sync.rd.service')=='true' and rd_master_token:
			from acctmgr.modules.sync import debrid_rd
			debrid_rd.Auth().realdebrid_auth()
	except Exception:
		log_utils.error("Startup Real-Debrid Sync FAILED")
	
	try:
		if control.setting('sync.pm.service')=='true' and pm_master_token:
			from acctmgr.modules.sync import debrid_pm
			debrid_pm.Auth().premiumize_auth()
	except Exception:
		log_utils.error("Startup Premiumize Sync FAILED")

	try:
		if control.setting('sync.ad.service')=='true' and ad_master_token:
			from acctmgr.modules.sync import debrid_ad 
			debrid_ad.Auth().alldebrid_auth()
	except Exception:
		log_utils.error("Startup All-Debrid Sync FAILED")

	try:	
		if control.setting('sync.ed.service')=='true' and ed_master_token:
			from acctmgr.modules.sync import easydebrid_sync
			easydebrid_sync.Auth().easydebrid_auth()
	except Exception:
		log_utils.error("Startup Easy-Debrid Sync FAILED")

	try:	
		if control.setting('sync.tb.service')=='true' and tb_master_token:
			from acctmgr.modules.sync import torbox_sync
			torbox_sync.Auth().torbox_auth()
	except Exception:
		log_utils.error("Startup Torbox Sync FAILED")

	try:	
		if control.setting('sync.oc.service')=='true' and oc_master_token:
			from acctmgr.modules.sync import offcloud_sync
			offcloud_sync.Auth().offcloud_auth()
	except Exception:
		log_utils.error("Startup OffCloud Sync FAILED")

	try:	
		if control.setting('sync.en.service')=='true' and en_master_user and en_master_pass:
			from acctmgr.modules.sync import easynews_sync
			easynews_sync.Auth().easynews_auth()
	except Exception:
		log_utils.error("Startup Easynews Sync FAILED")

def ScraperCheck(): # Check for installed scraper packages and update AM settings accordingly
	for addon_id, setting_id in (
		('script.module.cocoscrapers',  "ext.provider_coco"),
                ('script.module.gearsscrapers',  "ext.provider_gears"),
		('script.module.magneto',   "ext.provider_mag"),
		('script.module.viperscrapers', "ext.provider_vip"),
	):
		value = 'true' if xbmc.getCondVisibility(f'System.HasAddon({addon_id})') else 'false'
		control.setSetting(setting_id, value)

# START SERVICES
SyncManager()
ScraperCheck()
