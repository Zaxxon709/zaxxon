# -*- coding: utf-8 -*-
import xbmcvfs
from datetime import datetime
import inspect

LOGDEBUG = 0
LOGINFO = 1
LOGWARNING = 2
LOGERROR = 3
LOGFATAL = 4
LOGNONE = 5  # not used

debug_list = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'FATAL']
DEBUGPREFIX = '[COLOR red][ AM Lite %s ][/COLOR]'
translatePath = xbmcvfs.translatePath
LOGPATH = translatePath('special://logpath/')

def log(msg, caller=None, level=LOGINFO):
	from acctmgr.modules.control import setting as getSetting, lang, joinPath, existsPath
	try:
		if getSetting('debug.enabled') != 'true':
			return
		debug_location = getSetting('debug.location')

		if isinstance(msg, int):
			msg = lang(msg)

		if not msg.isprintable():
			msg = '%s (NORMALIZED by log_utils.log())' % normalize(msg)
		if isinstance(msg, bytes):
			msg = '%s (ENCODED by log_utils.log())' % msg.decode('utf-8', errors='replace')

		if caller is not None and level != LOGERROR:
			func = inspect.currentframe().f_back.f_code
			line_number = inspect.currentframe().f_back.f_lineno
			caller = "%s.%s()" % (caller, func.co_name)
			msg = 'From func name: %s Line # :%s\n                       msg : %s' % (caller, line_number, msg)
		elif caller is not None and level == LOGERROR:
			msg = 'From func name: %s.%s() Line # :%s\n                       msg : %s' % (caller[0], caller[1], caller[2], msg)

		if debug_location == '1':
			log_file = joinPath(LOGPATH, 'acctmgr.log')
			if not existsPath(log_file):
				f = xbmcvfs.File(log_file, 'w')
				f.close()

			reverse_log = getSetting('debug.reversed') == 'true'
			line = '[%s %s] %s: %s' % (
				datetime.now().date(),
				str(datetime.now().time())[:8],
				DEBUGPREFIX % debug_list[level],
				msg
			)

			if not reverse_log:
				with open(log_file, 'a', encoding='utf-8') as f:
					f.write(line.rstrip('\r\n') + '\n')
			else:
				with open(log_file, 'r+', encoding='utf-8') as f:
					old = f.read()
					f.seek(0, 0)
					f.write(line.rstrip('\r\n') + '\n' + old)
		else:
			import xbmc
			xbmc.log('%s: %s' % (DEBUGPREFIX % debug_list[level], msg), level)
	except Exception as e:
		import xbmc, traceback
		traceback.print_exc()
		xbmc.log('[ script.module.acctmgr ] log_utils.log() Logging Failure: %s' % e, LOGERROR)

def error(message=None, exception=True):
	try:
		import sys
		if exception:
			_type, value, tb = sys.exc_info()
			filename = tb.tb_frame.f_code.co_filename
			name = tb.tb_frame.f_code.co_name
			linenumber = tb.tb_lineno
			errortype = _type.__name__
			errormessage = value or value.message
			if str(errormessage) == '':
				return
			if message:
				message += ' -> '
			else:
				message = ''
			message += str(errortype) + ' -> ' + str(errormessage)
			caller = [filename, name, linenumber]
		else:
			caller = None
		log(msg=message, caller=caller, level=LOGERROR)
	except Exception as e:
		import xbmc
		xbmc.log('[ script.module.acctmgr ] log_utils.error() Logging Failure: %s' % e, LOGERROR)

def clear_logFile():
	from acctmgr.modules.control import yesnoDialog, lang, joinPath, existsPath
	try:
		if not yesnoDialog(lang(32074), '', ''):
			return 'canceled'
		log_file = joinPath(LOGPATH, 'acctmgr.log')
		if not existsPath(log_file):
			f = xbmcvfs.File(log_file, 'w')
			f.close()
			return True
		with open(log_file, 'r+') as f:
			f.truncate(0)
		return True
	except Exception as e:
		import xbmc
		xbmc.log('[ script.module.acctmgr ] log_utils.clear_logFile() Failure: %s' % e, LOGERROR)
		return False

# ---- SINGLE LOG FILE VIEWER ----
def view_LogFile():
	from acctmgr.modules.control import addonPath, joinPath, existsPath, notification
	try:
		from acctmgr.windows.textviewer import TextViewerXML
		log_file = joinPath(LOGPATH, 'acctmgr.log')
		if not existsPath(log_file):
			return notification(message='No Log File to View')
		with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
			text = f.read()
		heading = '[B]Account Manager Lite - LogFile[/B]'
		win = TextViewerXML('textviewer.xml', addonPath(), heading=heading, text=text)
		win.run()
	except:
		error()

def upload_LogFile():
	from acctmgr.modules.control import joinPath, existsPath, notification, addonVersion, selectDialog, lang
	try:
		url = 'https://paste.kodi.tv/'
		log_file = joinPath(LOGPATH, 'acctmgr.log')
		if not existsPath(log_file):
			return notification(message='No Log File to Upload!')
		import requests
		with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
			text = f.read()
		UserAgent = 'acctmgr %s' % addonVersion()
		response = requests.post(url + 'documents', data=text.encode('utf-8', errors='ignore'), headers={'User-Agent': UserAgent})
		data = response.json()
		if 'key' in data:
			result = url + data['key']
			log('AM Lite log file uploaded to: %s' % result)
			listing = [('[COLOR gold]url:[/COLOR]  %s' % result, result)]
			select = selectDialog([i[0] for i in listing], lang(32349))
			if select == 0:
				copy2clip(result)
		else:
			notification(message='acctmgr Log upload failed')
	except:
		error('AM Lite log upload failed')

def copy2clip(txt):
	from sys import platform
	try:
		if platform == "win32":
			from subprocess import check_call
			cmd = "echo " + txt.replace('&', '^&').strip() + "|clip"
			check_call(cmd, shell=True)
		elif platform == "darwin":
			from subprocess import check_call
			check_call("echo " + txt.strip() + "|pbcopy", shell=True)
		elif platform == "linux":
			from subprocess import Popen, PIPE
			p = Popen(["xsel", "-pi"], stdin=PIPE)
			p.communicate(input=txt)
	except:
		error('Clipboard copy failed')

def normalize(msg):
	try:
		import unicodedata
		msg = ''.join(c for c in unicodedata.normalize('NFKD', msg) if unicodedata.category(c) != 'Mn')
		return str(msg)
	except:
		error()
		return msg
