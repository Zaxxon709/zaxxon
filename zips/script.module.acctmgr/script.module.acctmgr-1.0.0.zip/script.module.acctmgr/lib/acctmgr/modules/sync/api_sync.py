# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcvfs
import json
import os

from acctmgr.modules import var
from acctmgr.modules import log_utils

# Variables
exists = xbmcvfs.exists
translatePath = xbmcvfs.translatePath

def get_trakt_sync_list():
    if not exists(var.tk_sync_list):
        return []
    try:
        with open(var.tk_sync_list, "r") as f:
            return json.load(f).get("addon_list", [])
    except Exception as e:
        return []

def check_restore_api(restore=False):
    
    current = get_trakt_sync_list()
    
    # ================= Seren =================
    if "Seren" in current and exists(var.chk_seren):
        try:
            with open(var.path_seren,'r') as f:
                data = f.read()
            new_data = None
            if restore:
                new_data = data.replace(var.client_am, var.seren_client).replace(var.secret_am, var.seren_secret)
            elif var.client_am in data:
                pass
            else:
                new_data = data.replace(var.seren_client, var.client_am).replace(var.seren_secret, var.secret_am)
            if new_data is not None:
                with open(var.path_seren, 'w') as f:
                    f.write(new_data)
        except Exception as e:
            log_utils.error("Seren API Failed")

    # ================= Umbrella =================
    if "Umbrella" in current and exists(var.chk_umb):
        try:
            with open(var.path_umb, 'r') as f:
                data = f.read()
            new_data = None
            if restore:
                new_data = data.replace(var.client_am, var.umb_client).replace(var.secret_am, var.umb_secret)
            elif var.client_am in data:
                pass
            else:
                new_data = data.replace(var.umb_client, var.client_am).replace(var.umb_secret, var.secret_am)
            if new_data is not None:
                with open(var.path_umb, 'w') as f:
                    f.write(new_data)
        except Exception as e:
            log_utils.error("Umbrella API Failed")

    # ================= Fen =================
    if "Fen" in current and exists(var.chk_fen):
        try:
            with open(var.path_fen, 'r') as f:
                data = f.read()
            new_data = None
            if restore:
                new_data = data.replace(var.client_am, var.fen_client).replace(var.secret_am, var.fen_secret)
            elif var.client_am in data:
                pass
            else:
                new_data = data.replace(var.fen_client, var.client_am).replace(var.fen_secret, var.secret_am)
            if new_data is not None:
                with open(var.path_fen, 'w') as f:
                    f.write(new_data)
        except Exception as e:
            log_utils.error("Fen API Failed")

    # ===========================================================
    # ======= IMPORTANT - THESE ADD-ONS ARE NOT MONITORED =======
    # ===========================================================
    # NOT monitored/compared with AM Lite API keys
    # Only REQUIRED action is to restore after a revoke
    # API keys are saved in settings.xml NOT python file

    # ================= POV =================
    if restore and exists(var.chk_pov):
        try:
            addon = xbmcaddon.Addon("plugin.video.pov")
            addon.setSetting("trakt.client_id", var.pov_client)
            addon.setSetting("trakt.client_secret", var.pov_secret)
        except Exception as e:
            log_utils.error("POV API Restore Failed")
    
    # ================= The Coalition =================
    if restore and exists(var.chk_coal):
        try:
            addon = xbmcaddon.Addon("plugin.video.coalition")
            addon.setSetting("trakt.client_id", var.chains_client)
            addon.setSetting("trakt.client_secret", var.chains_secret)
        except Exception as e:
            log_utils.error("The Coalition API Failed")

    # ================= Dradis =================
    if restore and exists(var.chk_dradis):
        try:
            addon = xbmcaddon.Addon("plugin.video.dradis")
            addon.setSetting("trakt.client_id", var.dradis_client)
            addon.setSetting("trakt.client_secret", var.dradis_secret)
        except Exception as e:
            log_utils.error("Dradis API Restore Failed")

    # ================= Genocide =================
    if restore and exists(var.chk_genocide):
        try:
            addon = xbmcaddon.Addon("plugin.video.genocide")
            addon.setSetting("trakt.client_id", var.chains_client)
            addon.setSetting("trakt.client_secret", var.chains_secret)
        except Exception as e:
            log_utils.error("Genocide API Failed")

    # =================================================
    # ========= END OF ADD-ONS NOT MONITORED ==========
    # =================================================
    
    # ================= Shadow =================
    if "Shadow" in current and exists(var.chk_shadow):
        try:
            with open(var.path_shadow, 'r') as f:
                data = f.read()
            new_data = None
            if restore:
                new_data = data.replace(var.client_am, var.shadow_client).replace(var.secret_am, var.shadow_secret)
            elif var.client_am in data:
                pass
            else:
                new_data = data.replace(var.shadow_client, var.client_am).replace(var.shadow_secret, var.secret_am)
            if new_data is not None:
                with open(var.path_shadow, 'w') as f:
                    f.write(new_data)
        except Exception as e:
            log_utils.error("Shadow API Failed")

    # ================= Ghost =================
    if "Ghost" in current and exists(var.chk_ghost):
        try:
            with open(var.path_ghost, 'r') as f:
                data = f.read()
            new_data = None
            if restore:
                new_data = data.replace(var.client_am, var.ghost_client).replace(var.secret_am, var.ghost_secret)
            elif var.client_am in data:
                pass
            else:
                new_data = data.replace(var.ghost_client, var.client_am).replace(var.ghost_secret, var.secret_am)
            if new_data is not None:
                with open(var.path_ghost, 'w') as f:
                    f.write(new_data)
        except Exception as e:
            log_utils.error("Ghost API Failed")

    # ================= The Crew =================
    if "The Crew" in current and exists(var.chk_crew):
        try:
            with open(var.path_crew, 'r') as f:
                data = f.read()
            new_data = None
            if restore:
                new_data = data.replace(var.client_am, var.crew_client).replace(var.secret_am, var.crew_secret)
            elif var.client_am in data:
                pass
            else:
                new_data = data.replace(var.crew_client, var.client_am).replace(var.crew_secret, var.secret_am)
            if new_data is not None:
                with open(var.path_crew, 'w') as f:
                    f.write(new_data)
        except Exception as e:
            log_utils.error("The Crew API Failed")

    # ================= Scrubs V2 =================
    if "Scrubs V2" in current and exists(var.chk_scrubs):
        try:
            with open(var.path_scrubs, 'r') as f:
                data = f.read()
            new_data = None
            if restore:
                new_data = data.replace(var.client_am, var.scrubs_client).replace(var.secret_am, var.scrubs_secret)
            elif var.client_am in data:
                pass
            else:
                new_data = data.replace(var.scrubs_client, var.client_am).replace(var.scrubs_secret, var.secret_am)
            if new_data is not None:
                with open(var.path_scrubs, 'w') as f:
                    f.write(new_data)
        except Exception as e:
            log_utils.error("Scrubs V2 API Failed")

    # ================= TMDbH =================
    if "TMDb Helper" in current and exists(var.chk_tmdbh):
        try:
            with open(var.path_tmdbh, 'r') as f:
                data = f.read()
            new_data = None
            if restore:
                new_data = data.replace(var.client_am, var.tmdbh_client).replace(var.secret_am, var.tmdbh_secret)
            elif var.client_am in data:
                pass
            else:
                new_data = data.replace(var.tmdbh_client, var.client_am).replace(var.tmdbh_secret, var.secret_am)
            if new_data is not None:
                with open(var.path_tmdbh, 'w') as f:
                    f.write(new_data)
        except Exception as e:
            log_utils.error("TMDbH API Failed")

    # ================= Trakt Add-on =================
    if "Trakt Addon" in current and exists(var.chk_trakt):
        try:
            with open(var.path_trakt, 'r') as f:
                data = f.read()
            new_data = None
            if restore:
                new_data = data.replace(var.client_am, var.trakt_client).replace(var.secret_am, var.trakt_secret)
            elif var.client_am in data:
                pass
            else:
                new_data = data.replace(var.trakt_client, var.client_am).replace(var.trakt_secret, var.secret_am)
            if new_data is not None:
                with open(var.path_trakt, 'w') as f:
                    f.write(new_data)
        except Exception as e:
            log_utils.error("Trakt Add-on API Failed")
