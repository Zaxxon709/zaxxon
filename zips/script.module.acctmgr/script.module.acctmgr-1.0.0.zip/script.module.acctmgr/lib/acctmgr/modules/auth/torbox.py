# -*- coding: utf-8 -*-
import xbmcgui
import json
import re
import urllib.request
import urllib.error
from acctmgr.modules import control
from acctmgr.modules import log_utils

# Variables
API_BASE = "https://api.torbox.app"
VALIDATE_PATH = "/v1/api/user/me"   # Account info endpoint
CST_REGEX = re.compile(r"cst_[A-Za-z0-9]+")
torbox_icon = control.joinPath(control.artPath(), 'torbox.png')

def _find_cst_id(obj):
	# Search JSON for a TorBox account id
	if isinstance(obj, dict):
		for v in obj.values():
			found = _find_cst_id(v)
			if found:
				return found
	elif isinstance(obj, list):
		for item in obj:
			found = _find_cst_id(item)
			if found:
				return found
	elif isinstance(obj, str):
		m = CST_REGEX.search(obj)
		if m:
			return m.group(0)
	return None

def _extract_account_status(payload):
	# TorBox account tier status
	try:
		data = payload.get("data") or {}
		plan = data.get("plan")
		is_subscribed = data.get("is_subscribed")
		expires = data.get("premium_expires_at")

		# Explicit premium indicators
		if is_subscribed is True or expires:
			return "Premium"

		# Plan-based fallback
		if plan == 0:
			return "Free"
		if plan == 1:
			return "Basic"
		if plan == 2:
			return "Premium"

	except Exception as e:
		log_utils.error(f"Error in _extract_account_status: {e}")

	return "Unknown"

def _extract_expiry_date(payload):
	# Extract TorBox premium expiry date (YYYY-MM-DD).
	try:
		expires = (payload.get("data") or {}).get("premium_expires_at")
		if not expires:
			return ""
		return expires.split("T", 1)[0]
	except Exception as e:
		log_utils.error(f"Error in _extract_expiry_date: {e}")
		return ""

class Torbox:
	def auth(self):
		api = xbmcgui.Dialog().input('Enter TorBox API Key:')
		if not api:
			control.notification(message="TorBox authorization cancelled!", icon=torbox_icon)
			return False

		api = api.strip()
		if not api:
			control.notification(message="TorBox authorization failed!", icon=torbox_icon)
			return False

		url = f"{API_BASE}{VALIDATE_PATH}"
		req = urllib.request.Request(url)
		req.add_header("Authorization", f"Bearer {api}")

		try:
			response = urllib.request.urlopen(req, timeout=10)
			data = json.loads(response.read().decode("utf-8"))

			# Account ID
			acct_id = _find_cst_id(data)
			if not acct_id:
				acct_id = (
					data.get("id")
					or data.get("user_id")
					or (data.get("user") or {}).get("id")
				)

			# Account Status
			acct_status = _extract_account_status(data)

			# Save Settings
			control.setSetting("torbox.token", api)

			if acct_id:
				control.setSetting("torbox.acct_id", str(acct_id))

			control.setSetting("torbox.auth_status", acct_status)

			control.notification(
				title="TorBox",
				message="TorBox Successfully Authorized!",
				icon=torbox_icon
			)
			return True

		except urllib.error.HTTPError as e:
			if e.code == 401:
				control.notification(
					message="TorBox Authorization Failed (Invalid API Key)",
					icon=torbox_icon
				)
			elif e.code == 404:
				control.notification(
					message="TorBox Authorization Failed (Bad Endpoint)",
					icon=torbox_icon
				)
			else:
				control.notification(
					message=f"TorBox Authorization Failed (HTTP {e.code})",
					icon=torbox_icon
				)
			return False

		except Exception as e:
			log_utils.error(f"TorBox authorization failed: {e}")
			control.notification(
				message="TorBox Authorization Failed",
				icon=torbox_icon
			)
			return False

	def revoke(self):
		if not control.okDialog("TorBox", "Revoke TorBox Authorization?"):
			return

		control.setSetting("torbox.token", "")
		control.setSetting("torbox.acct_id", "")
		control.setSetting("torbox.auth_status", "")

		control.notification("TorBox Authorization Revoked", icon=torbox_icon)
