# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcvfs
import os

from acctmgr.modules import var, control, log_utils
from acctmgr.modules.db import maxql_db

exists = xbmcvfs.exists
copy = xbmcvfs.copy
joinPath = os.path.join

class MaxQL:
    # QUALITY MAPS
    NUMERIC_QUALITY_MAP = {
        var.QL_UHD: '0',
        var.QL_HD:  '1',
        var.QL_SD:  '2',
    }
    FEN_QUALITY_MAP = {
        var.QL_UHD: 'SD, 720p, 1080p, 4K',
        var.QL_HD:  'SD, 720p, 1080p',
        var.QL_SD:  'SD, 720p',
    }
    SHADOW_QUALITY_MAP = {
        var.QL_UHD: '2',
        var.QL_HD:  '1',
        var.QL_SD:  '0',
    }
    OTAKU_QUALITY_MAP = {
        var.QL_UHD: '4',
        var.QL_HD:  '3',
        var.QL_SD:  '2',
    }
    CREW_QUALITY_MAP = {
        var.QL_UHD: '0',
        var.QL_HD:  '2',
        var.QL_SD:  '3',
    }

    def set_res(self, mode):

        num_quality     = self.NUMERIC_QUALITY_MAP.get(mode)
        fen_quality     = self.FEN_QUALITY_MAP.get(mode)
        shadow_quality  = self.SHADOW_QUALITY_MAP.get(mode)
        otaku_quality   = self.OTAKU_QUALITY_MAP.get(mode)
        crew_quality    = self.CREW_QUALITY_MAP.get(mode)

        if not all((fen_quality, num_quality, otaku_quality, crew_quality)):
            log_utils.error(f"MaxQL: Invalid mode received: {mode}")
            return

        # ===================== Copy Addon Data (settings.xml) =====================
        addons = (
            ("Shadow",      var.chk_shadow, var.shadow_ud,  var.chkset_shadow,  var.shadow),
            ("Ghost",       var.chk_ghost,  var.ghost_ud,   var.chkset_ghost,   var.ghost),
            ("Homelander",  var.chk_home,   var.home_ud,    var.chkset_home,    var.home),
            ("Nightwing",   var.chk_night,  var.night_ud,   var.chkset_night,   var.night),
            ("Absolution",  var.chk_absol,  var.absol_ud,   var.chkset_absol,   var.absol),
            ("The Crew",    var.chk_crew,   var.crew_ud,    var.chkset_crew,    var.crew),
            ("Scrubs V2",   var.chk_scrubs, var.scrubs_ud,  var.chkset_scrubs,  var.scrubs),
            ("Otaku",       var.chk_otaku,  var.otaku_ud,   var.chkset_otaku,   var.otaku),
        )

        for name, chk_addon, ud_path, chk_setting, base_path in addons:
            control.copy_addon_settings(
                name,
                chk_addon,
                ud_path,
                chk_setting,
                base_path
            )

        # ======================= Fen Light =======================
        try:
            if exists(var.chk_fenlt):
                if not exists(var.chkset_fenlt):
                    control.remake_settings(var.fenlt_id, var.fenlt_name)
                    xbmc.sleep(500)

                if exists(var.chkset_fenlt):
                    maxql_db.apply_quality(mode)
                    xbmc.sleep(300)
                    control.remake_settings(var.fenlt_id, var.fenlt_name)
        except Exception as e:
            log_utils.error("Fen Light MaxQL Failed")

        # ======================= Gears =======================
        try:
            if exists(var.chk_gears):
                if not exists(var.chkset_gears):
                    control.remake_settings(var.gears_id, var.gears_name)
                    xbmc.sleep(500)

                if exists(var.chkset_gears):
                    maxql_db.apply_quality(mode)
                    xbmc.sleep(300)
                    control.remake_settings(var.gears_id, var.gears_name)
        except Exception as e:
            log_utils.error("Gears MaxQL Failed")

        # ===================== Umbrella ======================
        try:
            if exists(var.chk_umb) and exists(var.chkset_umb):
                xbmcaddon.Addon("plugin.video.umbrella").setSetting(
                    "hosts.quality", num_quality
                )
        except Exception as e:
            log_utils.error("Umbrella MaxQL Failed")

        # ===================== Fen / POV / The Coalition =====================
        for name, plugin, chk_addon, chk_setting in (
            ("Fen", "plugin.video.fen", var.chk_fen, var.chkset_fen),
            ("POV", "plugin.video.pov", var.chk_pov, var.chkset_pov),
            ("The Coalition", "plugin.video.coalition", var.chk_coal, var.chkset_coal),
        ):
            try:
                if exists(chk_addon) and exists(chk_setting):
                    addon = xbmcaddon.Addon(plugin)
                    addon.setSetting("results_quality_movie", fen_quality)
                    addon.setSetting("results_quality_episode", fen_quality)
            except Exception as e:
                log_utils.error(f"{name} MaxQL Failed")

        # ===================== Dradis / Genocide =====================
        for name, plugin, chk_addon, chk_setting in (
            ("Dradis",   "plugin.video.dradis",   var.chk_dradis,   var.chkset_dradis),
            ("Genocide", "plugin.video.genocide", var.chk_genocide, var.chkset_genocide),
        ):
            try:
                if exists(chk_addon) and exists(chk_setting):
                    xbmcaddon.Addon(plugin).setSetting("hosts.quality", num_quality)
            except Exception as e:
                log_utils.error(f"{name} MaxQL Failed")

        # ===================== Shadow / Ghost =====================
        for name, plugin, chk_addon, chk_setting in (
            ("Shadow", "plugin.video.shadow", var.chk_shadow, var.chkset_shadow),
            ("Ghost",  "plugin.video.ghost",  var.chk_ghost,  var.chkset_ghost),
        ):
            try:
                if exists(chk_addon) and exists(chk_setting):
                    addon = xbmcaddon.Addon(plugin)
                    addon.setSetting("max_q", shadow_quality)
                    addon.setSetting("max_q_tv", shadow_quality)
            except Exception as e:
                log_utils.error(f"{name} MaxQL Failed")

        # =========== Homelander / Nightwing / Jokers Absolution ===========
        for name, plugin, chk_addon, chk_setting in (
            ("Homelander",        "plugin.video.homelander", var.chk_home,  var.chkset_home),
            ("Nightwing",         "plugin.video.nightwing",  var.chk_night, var.chkset_night),
            ("Jokers Absolution", "plugin.video.absolution", var.chk_absol, var.chkset_absol),
        ):
            try:
                if exists(chk_addon) and exists(chk_setting):
                    xbmcaddon.Addon(plugin).setSetting("hosts.quality", num_quality)
            except Exception as e:
                log_utils.error(f"{name} MaxQL Failed")

        # ===================== Seren =====================
        try:
            if exists(var.chk_seren) and exists(var.chkset_seren):
                xbmcaddon.Addon("plugin.video.seren").setSetting(
                    "general.maxResolution", num_quality
                )
        except Exception as e:
            log_utils.error("Seren MaxQL Failed")

        # ===================== The Crew =====================
        try:
            if exists(var.chk_crew) and exists(var.chkset_crew):
                xbmcaddon.Addon("plugin.video.thecrew").setSetting(
                    "quality.max", crew_quality
                )
        except Exception as e:
            log_utils.error("The Crew MaxQL Failed")

        # ===================== Otaku =====================
        try:
            if exists(var.chk_otaku) and exists(var.chkset_otaku):
                xbmcaddon.Addon("plugin.video.otaku").setSetting(
                    "general.maxResolution", otaku_quality
                )
        except Exception as e:
            log_utils.error("Otaku MaxQL Failed")

        # ===================== Scrubs V2 =====================
        try:
            if exists(var.chk_scrubs) and exists(var.chkset_scrubs):
                xbmcaddon.Addon("plugin.video.scrubsv2").setSetting(
                    "quality.max", num_quality
                )
        except Exception as e:
            log_utils.error("Scrubs V2 MaxQL Failed")
