# -*- coding: utf-8 -*-
import os
import shutil
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import sqlite3
import zipfile
import tempfile
import json
import xml.etree.ElementTree as ET

dialog = xbmcgui.Dialog()
translatePath = xbmcvfs.translatePath
addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(addon_id)
addon_info = addon.getAddonInfo
addon_path = translatePath(addon_info('path'))
addon_data = translatePath('special://profile/addon_data/')
addon_icon = translatePath('special://home/addons/script.fentastic.helper/resources/icon.png')

#Skin Backup/Restore Variables
db_dst_dir = xbmcvfs.translatePath("special://profile/addon_data/script.fentastic.helper/")
home = translatePath('special://home/')
user_path = os.path.join(home, 'userdata/')
data_path = os.path.join(user_path, 'addon_data/')
skin_path = translatePath('special://skin/')
skin = ET.parse(os.path.join(skin_path, 'addon.xml'))
root = skin.getroot()
skin_id = root.attrib['id']

#GUI/FAV Variables
gui_file = 'guisettings.xml'
fav_file = 'favourites.xml'

#Menu/Widget Default Configs
dst_cfg = xbmcvfs.translatePath('special://skin/xml/')
dst_db = os.path.join(addon_data, 'script.fentastic.helper/')

fen_cfg = os.path.join(skin_path, 'resources/pre_configs/Fen_Light_Basic/menus_widgets/')
fen_db = os.path.join(skin_path, 'resources/pre_configs/Fen_Light_Basic/database/')

fen_tk_cfg = os.path.join(skin_path, 'resources/pre_configs/Fen_Light_Trakt/menus_widgets/')
fen_tk_db = os.path.join(skin_path, 'resources/pre_configs/Fen_Light_Trakt/database/')

fen_anime_cfg = os.path.join(skin_path, 'resources/pre_configs/Fen_Light_Anime/menus_widgets/')
fen_anime_db = os.path.join(skin_path, 'resources/pre_configs/Fen_Light_Anime/database/')

red_cfg = os.path.join(skin_path, 'resources/pre_configs/Red_Light_Basic/menus_widgets/')
red_db = os.path.join(skin_path, 'resources/pre_configs/Red_Light_Basic/database/')

red_tk_cfg = os.path.join(skin_path, 'resources/pre_configs/Red_Light_Trakt/menus_widgets/')
red_tk_db = os.path.join(skin_path, 'resources/pre_configs/Red_Light_Trakt/database/')

red_anime_cfg = os.path.join(skin_path, 'resources/pre_configs/Red_Light_Anime/menus_widgets/')
red_anime_db = os.path.join(skin_path, 'resources/pre_configs/Red_Light_Anime/database/')

pov_cfg = os.path.join(skin_path, 'resources/pre_configs/POV_Basic/menus_widgets/')
pov_db = os.path.join(skin_path, 'resources/pre_configs/POV_Basic/database/')

pov_tk_cfg = os.path.join(skin_path, 'resources/pre_configs/POV_Trakt/menus_widgets/')
pov_tk_db = os.path.join(skin_path, 'resources/pre_configs/POV_Trakt/database/')

pov_anime_cfg = os.path.join(skin_path, 'resources/pre_configs/POV_Anime/menus_widgets/')
pov_anime_db = os.path.join(skin_path, 'resources/pre_configs/POV_Anime/database/')

umb_cfg = os.path.join(skin_path, 'resources/pre_configs/Umbrella_Basic/menus_widgets/')
umb_db = os.path.join(skin_path, 'resources/pre_configs/Umbrella_Basic/database/')

umb_tk_cfg = os.path.join(skin_path, 'resources/pre_configs/Umbrella_Trakt/menus_widgets/')
umb_tk_db = os.path.join(skin_path, 'resources/pre_configs/Umbrella_Trakt/database/')

gears_cfg = os.path.join(skin_path, 'resources/pre_configs/The_Gears_Basic/menus_widgets/')
gears_db = os.path.join(skin_path, 'resources/pre_configs/The_Gears_Basic/database/')

gears_tk_cfg = os.path.join(skin_path, 'resources/pre_configs/The_Gears_Trakt/menus_widgets/')
gears_tk_db = os.path.join(skin_path, 'resources/pre_configs/The_Gears_Trakt/database/')

tmdbh_cfg = os.path.join(skin_path, 'resources/pre_configs/TMDbH/menus_widgets/')
tmdbh_db = os.path.join(skin_path, 'resources/pre_configs/TMDbH/database/')


# -------------------------------------------------
# HELPERS
# -------------------------------------------------
def get_keyboard_text(default=""): #Open Kodi keyboard and return input
    kb = xbmc.Keyboard(default, "Enter name for your backup")
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText().strip()
        return text if text else None
    return None

#Create directory if it doesn't exist
def ensure_dir(path):
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)

#Copy file
def copy_file(src, dst):
    try:
        ensure_dir(os.path.dirname(dst))
        xbmcvfs.copy(src, dst)
    except Exception as e:
        dialog.notification("Backup Error", str(e), xbmcgui.NOTIFICATION_ERROR, 3000)

# Check if an addon is installed
def addon_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except:
        return False

# Copy all files from source to destination
def copy_all_files(src_dir, dst_dir):
    # Make sure destination exists
    os.makedirs(dst_dir, exist_ok=True)

    # Loop through items in source directory
    for item in os.listdir(src_dir):
        src_path = os.path.join(src_dir, item)
        dst_path = os.path.join(dst_dir, item)

        # Copy only files (skip subdirectories)
        if os.path.isfile(src_path):
            shutil.copy2(src_path, dst_path)
            
# Delete files starting with
def delete_files_starting_with(directory, prefix):
    # Ensure directory ends with slash
    if not directory.endswith(("/", "\\")):
        directory += "/"

    # List the directory contents
    try:
        dirs, files = xbmcvfs.listdir(directory)
    except Exception as e:
        xbmc.log(f"Error reading directory: {e}", xbmc.LOGERROR)
        return

    # Loop through files and delete those starting with prefix
    for file_name in files:
        if file_name.startswith(prefix):
            full_path = os.path.join(directory, file_name)
            xbmcvfs.delete(full_path)

# Apply Default Config XML files
def apply_default_config_xmls():
    src = xbmcvfs.translatePath('special://skin/resources/default_configs/')
    dst = xbmcvfs.translatePath('special://skin/xml/')

    if not src.endswith(("/", "\\")):
        src += "/"

    if not dst.endswith(("/", "\\")):
        dst += "/"

    if not xbmcvfs.exists(src):
        xbmc.log(f"FENtastic Plus: default config path missing: {src}", xbmc.LOGERROR)
        return False

    dirs, files = xbmcvfs.listdir(src)

    for file_name in files:
        if file_name.startswith('script-fentastic') and file_name.endswith('.xml'):
            src_file = src + file_name
            dst_file = dst + file_name
            xbmcvfs.copy(src_file, dst_file)

    return True

# Write Main Menu icons to settings
def write_pre_config_main_menu_icons(cfg_src):
    icon_settings = {
        "script-fentastic-main_menu_movies.xml": "movie.main_menu_icon",
        "script-fentastic-main_menu_tvshows.xml": "tvshow.main_menu_icon",
        "script-fentastic-main_menu_custom1.xml": "custom1.main_menu_icon",
        "script-fentastic-main_menu_custom2.xml": "custom2.main_menu_icon",
        "script-fentastic-main_menu_custom3.xml": "custom3.main_menu_icon",
        "script-fentastic-main_menu_custom4.xml": "custom4.main_menu_icon",
        "script-fentastic-main_menu_custom5.xml": "custom5.main_menu_icon",
        "script-fentastic-main_menu_custom6.xml": "custom6.main_menu_icon",
    }

    for file_name, skin_key in icon_settings.items():
        xml_path = os.path.join(cfg_src, file_name)

        if not os.path.exists(xml_path):
            continue

        try:
            with open(xml_path, "r", encoding="utf-8") as f:
                data = f.read()

            start = data.find("<thumb>")
            end = data.find("</thumb>", start)

            if start == -1 or end == -1:
                continue

            icon = data[start + len("<thumb>"):end].strip().replace('"', "'")

            if icon:
                xbmc.executebuiltin(f'Skin.SetString({skin_key},"{icon}")')
                xbmc.sleep(50)

        except Exception as e:
            xbmc.log(f"FENtastic Plus: failed to read pre-config icon from {xml_path}. Reason: {e}",xbmc.LOGERROR)

# Apply Pre-Config XML files
def apply_pre_config(cfg_src, db_src, search_provider):
    apply_default_config_xmls()
    enable_pre_config_home_menu_toggles()
    xbmc.executebuiltin(f'Skin.SetString(current_search_provider,"{search_provider}")')
    copy_all_files(cfg_src, dst_cfg)
    write_pre_config_main_menu_icons(dst_cfg)
    copy_all_files(db_src, dst_db)

	
# -------------------------------------------------
# BACKUP HELPERS
# -------------------------------------------------
def choose_backup_directory():
    path = xbmcgui.Dialog().browseSingle(3, "Choose Backup Directory", "")

    if not path:
        return

    xbmc.executebuiltin('Skin.SetString(backup_directory,"%s")' % path)
    dialog.ok("FENtastic Plus", "Backup directory saved.[CR][CR]Location:[CR][COLOR=gold]%s[/COLOR]" % os.path.normpath(path))

def get_backup_directory():
    path = xbmc.getInfoLabel("Skin.String(backup_directory)")

    if path:
        return xbmcvfs.translatePath(path)

    return xbmcvfs.translatePath("special://home/backups/FENtastic_Plus/")

def get_backup_subdir(folder_name):
    path = os.path.join(get_backup_directory(), folder_name)
    ensure_dir(path)
    return path

def backup_file(src, dst, backup_name):
    if not xbmcvfs.exists(src):
        xbmcgui.Dialog().notification("FENtastic Plus", "No %s file found." % backup_name, addon_icon, 3000)
        return False

    if xbmcvfs.exists(dst):
        if not xbmcgui.Dialog().yesno("FENtastic Plus", "A %s backup already exists.\n\nDo you want to overwrite it?" % backup_name):
            return False

        if not xbmcvfs.delete(dst):
            xbmc.log("Failed to delete existing %s backup: %s" % (backup_name, dst), xbmc.LOGERROR)
            xbmcgui.Dialog().notification("FENtastic Plus", "Failed to overwrite existing backup.", addon_icon, 3000)
            return False

    if not xbmcvfs.copy(src, dst):
        xbmc.log("Failed to backup %s from %s to %s" % (backup_name, src, dst), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("FENtastic Plus", "Backup Failed", addon_icon, 3000)
        return False

    xbmcgui.Dialog().notification("FENtastic Plus", "Backup Complete", addon_icon, 3000)
    return True

def restore_file(src, dst, backup_name):
    if not xbmcvfs.exists(src):
        xbmcgui.Dialog().notification("FENtastic Plus", "No %s backup found." % backup_name, addon_icon, 3000)
        return False

    if not xbmcgui.Dialog().yesno("FENtastic Plus", "Are you sure?"):
        return False

    if xbmcvfs.exists(dst):
        if not xbmcvfs.delete(dst):
            xbmc.log("Failed to delete existing %s file: %s" % (backup_name, dst), xbmc.LOGERROR)
            xbmcgui.Dialog().notification("FENtastic Plus", "Restore Failed", addon_icon, 3000)
            return False

    if not xbmcvfs.copy(src, dst):
        xbmc.log("Failed to restore %s from %s to %s" % (backup_name, src, dst), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("FENtastic Plus", "Restore Failed", addon_icon, 3000)
        return False

    return True

def import_backup(folder_name, file_name, backup_name):
    src = dialog.browseSingle(1, "Select %s" % backup_name, "")
    if not src:
        return

    dst = os.path.join(get_backup_subdir(folder_name), file_name)

    if os.path.exists(dst):
        if not dialog.yesno("FENtastic Plus", "A %s backup already exists.\n\nOverwrite it?" % backup_name):
            return

        xbmcvfs.delete(dst)

    copy_file(src, dst)

    if dialog.yesno("FENtastic Plus", "%s imported successfully.\n\nRestore it now?" % backup_name):
        if folder_name == "gui_bkup":
            restore_gui()
        else:
            restore_favs()
            
def export_backup(folder_name, backup_name):
    backup_dir = get_backup_subdir(folder_name)

    files = xbmcvfs.listdir(backup_dir)[1]
    if not files:
        dialog.ok("Export Error", "No %s backup found." % backup_name)
        return

    backup_file = files[0]
    src = os.path.join(backup_dir, backup_file)

    dest_dir = dialog.browseSingle(3, "Choose Export Location", "")
    if not dest_dir:
        return

    dst = os.path.join(dest_dir, backup_file)

    copy_file(src, dst)

    dialog.notification("FENtastic Plus", "%s exported." % backup_name, addon_icon, 3000)


# -------------------------------------------------
# GUI & FAVS BACKUP/RESTORE FUNCTIONS
# -------------------------------------------------
# Backup GUI settings
def backup_gui():
    if not xbmcgui.Dialog().yesno("FENtastic Plus", "Are you sure?"):
        return

    src = os.path.join(user_path, gui_file)
    dst = os.path.join(get_backup_subdir("gui_bkup"), gui_file)

    backup_file(src, dst, "GUI settings")

# Restore GUI settings
def restore_gui(gui_save=None):
    if gui_save is None:
        gui_save = get_backup_subdir("gui_bkup")

    src = os.path.join(gui_save, gui_file)
    dst = os.path.join(user_path, gui_file)

    if not restore_file(src, dst, "GUI settings"):
        return
    
    xbmcgui.Dialog().notification("FENtastic Plus", "Restore Complete", addon_icon, 3000)
    xbmcgui.Dialog().ok("FENtastic Plus", "To save changes you now need to force close Kodi.\n\nPress OK to force close Kodi.")
    os._exit(1)

# Backup Favourites
def backup_favs():
    if not xbmcgui.Dialog().yesno("FENtastic Plus", "Are you sure?"):
        return

    src = os.path.join(user_path, fav_file)
    dst = os.path.join(get_backup_subdir("favs_bkup"), fav_file)

    backup_file(src, dst, "favourites")

# Restore Favourites
def restore_favs():
    src = os.path.join(get_backup_subdir("favs_bkup"), fav_file)
    dst = os.path.join(user_path, fav_file)

    if not restore_file(src, dst, "favourites"):
        return

    xbmcgui.Dialog().notification("FENtastic Plus", "Restore Complete", addon_icon, 3000)
    xbmcgui.Dialog().ok("FENtastic Plus", "To save changes you now need to force close Kodi.\n\nPress OK to force close Kodi.")
    os._exit(1)

# Restore Skin Settings
def restore_skin(skin_save):
    if not os.path.exists(skin_save):
        xbmcgui.Dialog().notification("FENtastic Plus", "No default skin settings found.", addon_icon, 3000)
        return

    if not xbmcgui.Dialog().yesno("FENtastic Plus", "Restore the default skin settings.\nAre you sure?"):
        return

    skin_data = os.path.join(data_path, skin_id)
    base_path = translatePath("special://home/addons/skin.fentastic/")
    src = os.path.join(base_path, "resources", "default_colors", "fentastic_plus", "defaults.xml")
    dst = os.path.join(base_path, "colors", "defaults.xml")

    try:
        shutil.copytree(skin_save, skin_data, dirs_exist_ok=True)
        copy_file(src, dst)
    except Exception as e:
        xbmc.log("Failed to restore %s. Reason: %s" % (skin_data, e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("FENtastic Plus", "Restore Failed", addon_icon, 3000)
        return

    xbmcgui.Dialog().notification("FENtastic Plus", "Restore Complete", addon_icon, 3000)
    xbmcgui.Dialog().ok("FENtastic Plus", "To save changes you now need to force close Kodi.\n\nPress OK to force close Kodi.")
    os._exit(1)


# -------------------------------------------------
# USER-CONFIG BACKUP FUNCTION
# -------------------------------------------------
def backup_config():
    backup_name = get_keyboard_text()
    if not backup_name:
        dialog.ok("Backup Canceled", "No backup name was entered.")
        return

    # Backup Gui Settings & Favourites (Optional)
    include_gui = dialog.yesno(
        "Backup GUI Settings",
        "Include Kodi GUI settings in this backup?[CR][CR]"
        "[COLOR=yellow]Warning:[/COLOR] These settings include device-specific "
        "audio, display and hardware options.[CR][CR]"
        "Restoring them on a different device may cause audio, display or playback problems. "
        "Select No if you plan to use this backup on another device.",
        nolabel="No", yeslabel="Yes"
    )

    favs_source = translatePath("special://profile/favourites.xml")
    include_favs = os.path.isfile(favs_source) and dialog.yesno(
        "Backup Favourites", "Include Kodi favourites in this backup?",
        nolabel="No", yeslabel="Yes"
    )

    base_backup_dir = get_backup_subdir("User_Configs")
    backup_dir = os.path.join(base_backup_dir, backup_name)
    zip_path = backup_dir + ".zip"
    skin_backup_dir = os.path.join(backup_dir, "skin_files")
    skin_settings_backup_dir = os.path.join(backup_dir, "skin_settings")

    try:
        if os.path.exists(backup_dir):
            shutil.rmtree(backup_dir)
        if os.path.exists(zip_path) and not dialog.yesno(
                "Backup Exists", "A backup with this name exists.[CR][CR]Overwrite it?"):
            return
        os.makedirs(skin_backup_dir)
        os.makedirs(skin_settings_backup_dir)

        def backup_copy(src, dst):
            if not os.path.isfile(src):
                raise IOError("Required backup source missing: %s" % src)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)

        xml_dir = translatePath("special://skin/xml/")
        for filename in os.listdir(xml_dir):
            low = filename.lower()
            if ("script-fentastic" in low or low == "includes_mainmenu.xml") and os.path.isfile(os.path.join(xml_dir, filename)):
                backup_copy(os.path.join(xml_dir, filename), os.path.join(skin_backup_dir, filename))

        db_src = translatePath("special://profile/addon_data/script.fentastic.helper/cpath_cache.db")
        if os.path.isfile(db_src):
            backup_copy(db_src, os.path.join(backup_dir, "cpath_cache.db"))

        skin_data_src = os.path.join(data_path, skin_id)
        if not os.path.isdir(skin_data_src):
            raise IOError("Skin settings directory not found: %s" % skin_data_src)
        shutil.copytree(skin_data_src, os.path.join(skin_settings_backup_dir, skin_id))

        result = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue",
            "params": {"setting": "lookandfeel.skincolors"}
        })))
        color_name = result["result"]["value"]
        if not isinstance(color_name, str) or not color_name:
            raise ValueError("No active skin color scheme returned")
        with open(os.path.join(backup_dir, "skin_color.json"), "w", encoding="utf-8") as f:
            json.dump({"lookandfeel.skincolors": color_name}, f)

        # Backup if files exist
        if include_gui:
            backup_copy(os.path.join(user_path, gui_file), os.path.join(backup_dir, gui_file))
        if include_favs:
            backup_copy(favs_source, os.path.join(backup_dir, fav_file))

        temp_zip = zip_path + ".tmp"
        try:
            with zipfile.ZipFile(temp_zip, "w", zipfile.ZIP_DEFLATED) as zipf:
                for root_dir, dirs, files in os.walk(backup_dir):
                    for filename in files:
                        file_path = os.path.join(root_dir, filename)
                        zipf.write(file_path, os.path.relpath(file_path, backup_dir))
            os.replace(temp_zip, zip_path)
        finally:
            if os.path.exists(temp_zip):
                os.remove(temp_zip)

    except Exception as e:
        xbmc.log("FENtastic Plus: user config backup failed: %s" % e, xbmc.LOGERROR)
        dialog.ok("Backup Failed", "Could not create backup:[CR]%s" % e)
        return
    finally:
        if os.path.isdir(backup_dir):
            shutil.rmtree(backup_dir, ignore_errors=True)

    dialog.ok("Backup Completed",
              "Backup saved as: [COLOR=gold]%s.zip[/COLOR][CR]Location:[CR][COLOR=gold]%s[/COLOR]" %
              (backup_name, os.path.normpath(zip_path)))


def write_restored_skin_color(gui_path, color_name):
    """Persist the selected skin color without relying on Kodi shutdown."""
    if not os.path.isfile(gui_path):
        raise IOError("Kodi GUI settings file not found: %s" % gui_path)
    tree = ET.parse(gui_path)
    root = tree.getroot()
    setting = root.find(".//setting[@id='lookandfeel.skincolors']")
    if setting is None:
        settings = root.find("settings") if root.tag != "settings" else root
        if settings is None:
            raise ValueError("Unrecognized Kodi GUI settings XML structure")
        setting = ET.SubElement(settings, "setting", {"id": "lookandfeel.skincolors"})
    if "value" in setting.attrib:
        setting.set("value", color_name)
    else:
        setting.text = color_name
    # Write to a temporary file and replace the original only on success.
    temp_path = gui_path + ".fentastic_restore_tmp"
    try:
        tree.write(temp_path, encoding="utf-8", xml_declaration=True)
        os.replace(temp_path, gui_path)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


# -------------------------------------------------
# USER-CONFIG RESTORE FUNCTION
# -------------------------------------------------
def restore_config():
    base_backup_dir = get_backup_subdir("User_Configs")
    zip_path = dialog.browseSingle(1, "Choose Backup To Restore", "", ".zip", False, False, base_backup_dir)
    if not zip_path:
        return
    if not zip_path.lower().endswith(".zip"):
        dialog.ok("Restore Error", "Selected file is not a ZIP archive.")
        return

    selected_backup = os.path.basename(zip_path)
    extract_path = tempfile.mkdtemp(prefix="fentastic_restore_")

    try:
        # Stage and validate everything before asking the user to close Kodi.
        with zipfile.ZipFile(zip_path, "r") as zipf:
            if zipf.testzip() is not None:
                raise ValueError("Backup ZIP failed its integrity check")
            base = os.path.realpath(extract_path)
            for info in zipf.infolist():
                target = os.path.realpath(os.path.join(base, info.filename))
                if not target.startswith(base + os.sep) and target != base:
                    raise ValueError("Unsafe path in backup ZIP")
            zipf.extractall(extract_path)

        skin_backup_path = os.path.join(extract_path, "skin_files")
        skin_settings_src = os.path.join(extract_path, "skin_settings", skin_id)
        if not os.path.isdir(skin_backup_path) or not os.path.isdir(skin_settings_src):
            raise ValueError("Backup is missing skin configuration files")

        backup_xmls = [f for f in os.listdir(skin_backup_path)
                       if os.path.isfile(os.path.join(skin_backup_path, f)) and f.lower().endswith(".xml")]
        if not backup_xmls:
            raise ValueError("No menu/widget XML files found in backup")
        for filename in backup_xmls:
            ET.parse(os.path.join(skin_backup_path, filename))

        saved_color = None
        color_metadata = os.path.join(extract_path, "skin_color.json")
        if os.path.isfile(color_metadata):
            with open(color_metadata, "r", encoding="utf-8") as f:
                saved_color = json.load(f).get("lookandfeel.skincolors")
            if not isinstance(saved_color, str) or not saved_color:
                raise ValueError("Invalid saved skin color setting")

        gui_src = os.path.join(extract_path, gui_file)
        if os.path.isfile(gui_src):
            ET.parse(gui_src)
            if not dialog.yesno(
                    "Restore GUI Settings",
                    "This backup includes guisettings.xml.[CR][CR]"
                    "[COLOR=yellow]Warning:[/COLOR] Restoring GUI settings will replace "
                    "your current Kodi-wide settings, including device-specific audio, "
                    "display and hardware options.[CR][CR]"
                    "Restoring settings from a different device may cause audio, display "
                    "or playback problems.[CR][CR]"
                    "Restore GUI settings? Select No to keep your current Kodi settings.",
                    nolabel="No", yeslabel="Yes"):
                gui_src = None
        else:
            gui_src = None

        fav_src = os.path.join(extract_path, fav_file)
        if os.path.isfile(fav_src):
            if not dialog.yesno(
                    "Restore Favourites",
                    "This backup includes favourites.xml.[CR][CR]"
                    "Restoring it will replace your current Kodi favourites.[CR][CR]"
                    "Restore favourites?",
                    nolabel="No", yeslabel="Yes"):
                fav_src = None
        else:
            fav_src = None

        db_src = os.path.join(extract_path, "cpath_cache.db")

        # Nothing has been applied to Kodi at this point.
        if not dialog.yesno(
            "Restore Ready",
            "Backup: [COLOR=gold]%s[/COLOR][CR][CR]"
            "Select OK to apply the backup and force close Kodi.[CR][CR]"
            "Restart Kodi to load the restored configuration." % selected_backup,
            nolabel="Cancel", yeslabel="OK"
        ):
            return

        # Apply only AFTER the user dismisses the dialog. Do not call Kodi's
        # normal shutdown: it could write its cached settings over these files.
        xml_dir = translatePath("special://skin/xml/")
        os.makedirs(xml_dir, exist_ok=True)
        for filename in os.listdir(xml_dir):
            if filename.lower().startswith("script-fentastic") and filename.lower().endswith(".xml"):
                os.remove(os.path.join(xml_dir, filename))
        for filename in backup_xmls:
            shutil.copy2(os.path.join(skin_backup_path, filename), os.path.join(xml_dir, filename))

        skin_settings_dst = os.path.join(data_path, skin_id)
        os.makedirs(skin_settings_dst, exist_ok=True)
        shutil.copytree(skin_settings_src, skin_settings_dst, dirs_exist_ok=True)

        if os.path.isfile(db_src):
            os.makedirs(db_dst_dir, exist_ok=True)
            shutil.copy2(db_src, os.path.join(db_dst_dir, "cpath_cache.db"))
        if fav_src:
            shutil.copy2(fav_src, os.path.join(user_path, fav_file))

        # Write GUI settings last. Persist the backed-up skin color directly
        # in the file so the immediate forced exit cannot discard the change.
        gui_dst = os.path.join(user_path, gui_file)
        if gui_src:
            shutil.copy2(gui_src, gui_dst)
        if saved_color is not None:
            write_restored_skin_color(gui_dst, saved_color)

        xbmc.log("FENtastic Plus: restored user config '%s'; force closing Kodi" % selected_backup,
                 xbmc.LOGINFO)
        os._exit(1)

    except Exception as e:
        xbmc.log("FENtastic Plus: user config restore failed: %s" % e, xbmc.LOGERROR)
        dialog.ok("Restore Failed", "Could not fully restore backup:[CR]%s" % e)
    finally:
        shutil.rmtree(extract_path, ignore_errors=True)


# -------------------------------------------------
# USER-CONFIG EXPORT FUNCTION
# -------------------------------------------------
def export_config():
    base_backup_dir = get_backup_subdir("User_Configs")

    backups = [f for f in xbmcvfs.listdir(base_backup_dir)[1] if f.lower().endswith(".zip")]
    if not backups:
        dialog.ok("Export Error", "No backups available to export.")
        return

    index = dialog.select("Select Backup To Export", backups)
    if index < 0:
        return

    backup_name = backups[index]
    backup_path = os.path.join(base_backup_dir, backup_name)

    dest_dir = dialog.browseSingle(3, "Choose Export Location", "") # Select directory

    if not dest_dir:
        return

    if not dest_dir.endswith(("/", "\\")):
        dest_dir += "/"

    export_path = os.path.join(dest_dir, backup_name)

    try:
        if os.path.exists(export_path):
            os.remove(export_path)

        copy_file(backup_path, export_path)

    except Exception as e:
        dialog.ok("Export Error", f"Failed to export backup:\n{e}")
        return

    dialog.notification("FENtastic Plus",f"Backup exported as:\n{backup_name}",addon_icon,3000)

    
# -------------------------------------------------
# USER-CONFIG IMPORT FUNCTION
# -------------------------------------------------
def import_config():
    zip_path = dialog.browseSingle(1, "Select FENtastic Plus Backup ZIP", "", ".zip", False, False)

    if not zip_path:
        return

    if not zip_path.lower().endswith(".zip"):
        dialog.ok("Import Error", "Selected file is not a ZIP archive.")
        return

    base_backup_dir = get_backup_subdir("User_Configs")
    ensure_dir(base_backup_dir)

    backup_name = os.path.basename(zip_path)
    final_dst = os.path.join(base_backup_dir, backup_name)

    if os.path.exists(final_dst):
        overwrite = dialog.yesno("Backup Exists",f"A backup named '{backup_name}' already exists.\n\nOverwrite it?")
        if not overwrite:
            return
        os.remove(final_dst)

    try:
        copy_file(zip_path, final_dst)
    except Exception as e:
        dialog.ok("Import Error", f"Failed to import backup:\n{e}")
        return

    if dialog.yesno("Import Complete",f"Backup '{backup_name}' imported successfully.\n\nRestore it now?"):
        restore_config()


# -------------------------------------------------
# Enable Pre-Config Main Menu Toggles
# -------------------------------------------------
def enable_pre_config_home_menu_toggles():
    """
    Enables Movies, TV Shows, and Custom1-6
    Disables the default Kodi menu items not used by pre-configs
    """
    enabled_settings = [
        "HomeMenuNoMoviesButton",
        "HomeMenuNoTVShowsButton",
        "HomeMenuNoCustom1Button",
        "HomeMenuNoCustom2Button",
        "HomeMenuNoCustom3Button",
        "HomeMenuNoCustom4Button",
        "HomeMenuNoCustom5Button",
        "HomeMenuNoCustom6Button",
        "HomeMenuNoProgramsButton",
        "HomeMenuNoFavButton",
    ]

    disabled_settings = [
        "HomeMenuNoMusicButton",
        "HomeMenuNoMusicVideoButton",
        "HomeMenuNoTVButton",
        "HomeMenuNoRadioButton",
        "HomeMenuNoPicturesButton",
        "HomeMenuNoVideosButton",
        "HomeMenuNoGamesButton",
        "HomeMenuNoWeatherButton",
    ]

    for setting in enabled_settings:
        if xbmc.getCondVisibility(f"Skin.HasSetting({setting})"):
            xbmc.executebuiltin(f"Skin.Reset({setting})")
            xbmc.sleep(50)

    for setting in disabled_settings:
        if not xbmc.getCondVisibility(f"Skin.HasSetting({setting})"):
            xbmc.executebuiltin(f"Skin.SetBool({setting})")
            xbmc.sleep(50)


# -------------------------------------------------
# Main Menu Labels
# -------------------------------------------------
def load_all_menu_labels():
    """
    Reads all main menu labels from cpath_cache.db and assigns them
    to Skin.String() values for use in XML.
    """
    db_path = translatePath("special://profile/addon_data/script.fentastic.helper/cpath_cache.db")

    if not xbmcvfs.exists(db_path):
        return

    MENU_MAP = {
        "movie":   ("MenuMovieLabelDB",   "Movies"),
        "tvshow":  ("MenuTVShowLabelDB",  "TV Shows"),
        "custom1": ("MenuCustom1LabelDB", "Custom 1"),
        "custom2": ("MenuCustom2LabelDB", "Custom 2"),
        "custom3": ("MenuCustom3LabelDB", "Custom 3"),
        "custom4": ("MenuCustom4LabelDB", "Custom 4"),
        "custom5": ("MenuCustom5LabelDB", "Custom 5"),
        "custom6": ("MenuCustom6LabelDB", "Custom 6"),
    }

    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        for key, (skin_key, default_label) in MENU_MAP.items():

            setting_key = f"{key}.main_menu"

            cur.execute("SELECT cpath_header FROM custom_paths WHERE cpath_setting = ? LIMIT 1",(setting_key,))
            row = cur.fetchone()

            if row and row[0]:
                label = row[0]
                source = "DB"
            else:
                label = default_label
                source = "DEFAULT"

            safe = label.replace('"', "'")
            xbmc.executebuiltin(f'Skin.SetString({skin_key},"{safe}")')

        conn.close()

    except Exception as e:
        xbmc.log(f"DB Error loading menu labels: {e}", xbmc.LOGERROR)

        
# -------------------------------------------------
# PRE-MADE CONFIGURATIONS
# -------------------------------------------------
def preconfig_addon_notinstalled(addon):
	dialog.notification("FENtastic Plus", f"{addon} must be installed to use this pre-config.", addon_icon, 5000)
	
def run_pre_config_mode(config):
    config = str(config or "").strip().lower()

    configs = {
        "fenlight_basic":   {"label": "Fen Light Basic",    "cfg": fen_cfg,       "db": fen_db,       "search_provider": "1"},
        "fenlight_trakt":   {"label": "Fen Light Trakt",    "cfg": fen_tk_cfg,    "db": fen_tk_db,    "search_provider": "1"},
        "fenlight_anime":   {"label": "Fen Light Anime",    "cfg": fen_anime_cfg, "db": fen_anime_db, "search_provider": "1"},

        "redlight_basic":   {"label": "Red Light Basic",    "cfg": red_cfg,       "db": red_db,       "search_provider": "5"},
        "redlight_trakt":   {"label": "Red Light Trakt",    "cfg": red_tk_cfg,    "db": red_tk_db,    "search_provider": "5"},
        "redlight_anime":   {"label": "Red Light Anime",    "cfg": red_anime_cfg, "db": red_anime_db, "search_provider": "5"},

        "pov_basic":        {"label": "POV Basic",          "cfg": pov_cfg,       "db": pov_db,       "search_provider": "3"},
        "pov_trakt":        {"label": "POV Trakt",          "cfg": pov_tk_cfg,    "db": pov_tk_db,    "search_provider": "3"},
        "pov_anime":        {"label": "POV Anime",          "cfg": pov_anime_cfg, "db": pov_anime_db, "search_provider": "3"},

        "umbrella_basic":   {"label": "Umbrella Basic",     "cfg": umb_cfg,       "db": umb_db,       "search_provider": "2"},
        "umbrella_trakt":   {"label": "Umbrella Trakt",     "cfg": umb_tk_cfg,    "db": umb_tk_db,    "search_provider": "2"},

        "gears_basic":      {"label": "The Gears Basic",    "cfg": gears_cfg,     "db": gears_db,     "search_provider": "4"},
        "gears_trakt":      {"label": "The Gears Trakt",    "cfg": gears_tk_cfg,  "db": gears_tk_db,  "search_provider": "4"},

        "tmdbh":            {"label": "TMDb Helper",        "cfg": tmdbh_cfg,     "db": tmdbh_db,     "search_provider": "0"},
    }

    selected = configs.get(config)

    if not selected:
        dialog.ok("FENtastic Plus", "The selected pre-configuration is not available.")
        return

    mode_label = selected["label"]
    cfg_src = selected["cfg"]
    db_src = selected["db"]

    if not dialog.yesno("FENtastic Plus", f"Are you sure you want to apply the '[COLOR gold]{mode_label}[/COLOR]' pre-configuration?[CR][CR]This will overwrite your current menus and widgets.", nolabel="No", yeslabel="Yes"):
        return

    if not os.path.isdir(cfg_src) or not os.path.isdir(db_src):
        dialog.ok("FENtastic Plus", f"The files required for the '[COLOR gold]{mode_label}[/COLOR]' pre-configuration could not be found.")
        return

    apply_pre_config(cfg_src, db_src, selected["search_provider"])
    load_all_menu_labels()
    xbmc.executebuiltin("Skin.SetBool(noiconsilhouettes)")
    xbmc.executebuiltin("ReloadSkin()")
    dialog.notification("FENtastic Plus", f"{mode_label} config applied!", addon_icon, 3000)
